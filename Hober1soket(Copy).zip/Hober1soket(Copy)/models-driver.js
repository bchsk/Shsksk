const { initializeDatabase } = require('../config/database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

class Driver {
    constructor() {
        this.db = null;
        this.init();
    }

    async init() {
        this.db = await initializeDatabase();
    }

    async register(driverData) {
        const {
            busNumber,
            password,
            driverName,
            route,
            busId,
            companyId,
            secureToken
        } = driverData;

        try {
            // التحقق من الرابط الآمن إذا كان موجوداً
            if (secureToken) {
                const { valid, companyId: verifiedCompanyId } = await this.validateSecureToken(secureToken);
                if (!valid) {
                    throw new Error('الرابط الآمن غير صالح أو منتهي الصلاحية');
                }
                // استخدام companyId من الرابط الآمن
                companyId = verifiedCompanyId;
            }

            // التحقق من عدم وجود سائق بنفس رقم الحافلة
            const existingDriver = await this.db.get(
                'SELECT id FROM drivers WHERE bus_number = ?',
                [busNumber]
            );

            if (existingDriver) {
                throw new Error('سائق بنفس رقم الحافلة موجود مسبقاً');
            }

            // التحقق من حدود الشركة
            const companyLimit = await this.validateCompanyLimit(companyId);
            if (!companyLimit.canAddMore) {
                throw new Error('تم تجاوز الحد الأقصى للحافلات لهذه الشركة');
            }

            // تشفير كلمة السر
            const hashedPassword = await bcrypt.hash(password, 12);
            const driverUUID = uuidv4();
            const busUUID = uuidv4();

            // إنشاء الحافلة
            await this.db.run(
                `INSERT INTO buses (bus_id, company_id, driver_name, route, status, uuid) 
                 VALUES (?, ?, ?, ?, 'stopped', ?)`,
                [busId, companyId, driverName, route, busUUID]
            );

            // إنشاء السائق
            await this.db.run(
                `INSERT INTO drivers (bus_number, password, bus_id, driver_name, route, uuid) 
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [busNumber, hashedPassword, busId, driverName, route, driverUUID]
            );

            // تسجيل الحدث
            await this.logDriverEvent(busId, 'DRIVER_REGISTERED', {
                busNumber,
                driverName,
                route,
                companyId
            });

            return {
                busId,
                busNumber,
                driverName,
                route,
                companyId,
                message: 'تم تسجيل السائق بنجاح'
            };

        } catch (error) {
            console.error('❌ خطأ في تسجيل السائق:', error);
            throw error;
        }
    }

    async authenticate(busNumber, password) {
        try {
            const driver = await this.db.get(`
                SELECT d.*, b.driver_name, b.route, b.status as bus_status, 
                       b.company_id, c.name as company_name, c.status as company_status
                FROM drivers d 
                JOIN buses b ON d.bus_id = b.bus_id
                JOIN companies c ON b.company_id = c.id
                WHERE d.bus_number = ? AND c.status = 'active' AND b.status != 'deleted'
            `, [busNumber]);

            if (!driver) {
                throw new Error('رقم الحافلة أو كلمة السر غير صحيحة');
            }

            // التحقق من كلمة السر
            const isPasswordValid = await bcrypt.compare(password, driver.password);
            if (!isPasswordValid) {
                // تسجيل محاولة دخول فاشلة
                await this.recordFailedLoginAttempt(busNumber);
                throw new Error('رقم الحافلة أو كلمة السر غير صحيحة');
            }

            // إعادة تعيين عداد المحاولات الفاشلة
            await this.resetFailedLoginAttempts(busNumber);

            // تحديث آخر دخول
            await this.updateLastLogin(busNumber);

            // تسجيل حدث الدخول الناجح
            await this.logDriverEvent(driver.bus_id, 'DRIVER_LOGIN_SUCCESS', {
                busNumber,
                driverName: driver.driver_name
            });

            return {
                bus_id: driver.bus_id,
                bus_number: driver.bus_number,
                driver_name: driver.driver_name,
                route: driver.route,
                company_id: driver.company_id,
                company_name: driver.company_name,
                uuid: driver.uuid
            };

        } catch (error) {
            console.error('❌ خطأ في مصادقة السائق:', error);
            throw error;
        }
    }

    async getByBusId(busId) {
        try {
            const driver = await this.db.get(`
                SELECT d.*, b.driver_name, b.route, b.status as bus_status,
                       b.company_id, c.name as company_name
                FROM drivers d 
                JOIN buses b ON d.bus_id = b.bus_id
                JOIN companies c ON b.company_id = c.id
                WHERE d.bus_id = ? AND b.status != 'deleted'
            `, [busId]);

            if (!driver) {
                throw new Error('السائق غير موجود');
            }

            return driver;
        } catch (error) {
            console.error('❌ خطأ في جلب بيانات السائق:', error);
            throw error;
        }
    }

    async getByBusNumber(busNumber) {
        try {
            const driver = await this.db.get(`
                SELECT d.*, b.driver_name, b.route, b.status as bus_status,
                       b.company_id, c.name as company_name
                FROM drivers d 
                JOIN buses b ON d.bus_id = b.bus_id
                JOIN companies c ON b.company_id = c.id
                WHERE d.bus_number = ? AND b.status != 'deleted'
            `, [busNumber]);

            return driver;
        } catch (error) {
            console.error('❌ خطأ في جلب بيانات السائق:', error);
            throw error;
        }
    }

    async update(busNumber, updateData) {
        const allowedFields = ['driver_name', 'route', 'password'];
        const updates = [];
        const values = [];

        for (const [field, value] of Object.entries(updateData)) {
            if (allowedFields.includes(field)) {
                if (field === 'password') {
                    // تشفير كلمة السر الجديدة
                    const hashedPassword = await bcrypt.hash(value, 12);
                    updates.push('password = ?');
                    values.push(hashedPassword);
                } else {
                    updates.push(`${field} = ?`);
                    values.push(value);
                }
            }
        }

        if (updates.length === 0) {
            throw new Error('لا توجد حقول صالحة للتحديث');
        }

        values.push(busNumber);

        try {
            await this.db.run(
                `UPDATE drivers SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP 
                 WHERE bus_number = ?`,
                values
            );

            // تحديث بيانات الحافلة أيضاً إذا كانت متعلقة
            if (updateData.driver_name || updateData.route) {
                const busUpdates = [];
                const busValues = [];

                if (updateData.driver_name) {
                    busUpdates.push('driver_name = ?');
                    busValues.push(updateData.driver_name);
                }

                if (updateData.route) {
                    busUpdates.push('route = ?');
                    busValues.push(updateData.route);
                }

                const driver = await this.getByBusNumber(busNumber);
                busValues.push(driver.bus_id);

                await this.db.run(
                    `UPDATE buses SET ${busUpdates.join(', ')}, updated_at = CURRENT_TIMESTAMP 
                     WHERE bus_id = ?`,
                    busValues
                );
            }

            await this.logDriverEvent(busNumber, 'DRIVER_UPDATED', updateData);

            return { message: 'تم تحديث بيانات السائق بنجاح' };
        } catch (error) {
            console.error('❌ خطأ في تحديث السائق:', error);
            throw error;
        }
    }

    async delete(busNumber) {
        try {
            const driver = await this.getByBusNumber(busNumber);
            
            if (!driver) {
                throw new Error('السائق غير موجود');
            }

            // وضع علامة محذوفة على السائق والحافلة
            await this.db.run(
                'UPDATE drivers SET bus_number = CONCAT(bus_number, "_deleted_", ?), updated_at = CURRENT_TIMESTAMP WHERE bus_number = ?',
                [Date.now(), busNumber]
            );

            await this.db.run(
                'UPDATE buses SET status = "deleted", updated_at = CURRENT_TIMESTAMP WHERE bus_id = ?',
                [driver.bus_id]
            );

            await this.logDriverEvent(driver.bus_id, 'DRIVER_DELETED', {
                busNumber,
                driverName: driver.driver_name
            });

            return { message: 'تم حذف السائق بنجاح' };
        } catch (error) {
            console.error('❌ خطأ في حذف السائق:', error);
            throw error;
        }
    }

    async getAllByCompany(companyId, filter = {}) {
        try {
            let query = `
                SELECT d.*, b.driver_name, b.route, b.status as bus_status,
                       b.last_location_lat, b.last_location_lng, b.speed,
                       b.passengers, b.total_distance, b.last_update
                FROM drivers d 
                JOIN buses b ON d.bus_id = b.bus_id
                WHERE b.company_id = ? AND b.status != 'deleted'
            `;
            const params = [companyId];

            if (filter.status) {
                query += ' AND b.status = ?';
                params.push(filter.status);
            }

            if (filter.search) {
                query += ' AND (d.bus_number LIKE ? OR b.driver_name LIKE ? OR b.route LIKE ?)';
                const searchTerm = `%${filter.search}%`;
                params.push(searchTerm, searchTerm, searchTerm);
            }

            query += ' ORDER BY b.last_update DESC';

            const drivers = await this.db.all(query, params);
            return drivers;
        } catch (error) {
            console.error('❌ خطأ في جلب قائمة السائقين:', error);
            throw error;
        }
    }

    async getDriverStatistics(busNumber) {
        try {
            const driver = await this.getByBusNumber(busNumber);
            
            const stats = await this.db.get(`
                SELECT 
                    COUNT(bl.id) as total_trips,
                    SUM(bl.speed) as total_speed,
                    AVG(bl.speed) as avg_speed,
                    SUM(bl.passengers) as total_passengers,
                    MAX(bl.timestamp) as last_active,
                    COUNT(DISTINCT DATE(bl.timestamp)) as active_days
                FROM bus_locations bl
                WHERE bl.bus_id = ?
                AND bl.timestamp > datetime('now', '-30 days')
            `, [driver.bus_id]);

            const recentLocations = await this.db.all(`
                SELECT location_lat, location_lng, speed, passengers, timestamp
                FROM bus_locations 
                WHERE bus_id = ? 
                ORDER BY timestamp DESC 
                LIMIT 10
            `, [driver.bus_id]);

            return {
                ...stats,
                recent_locations: recentLocations,
                driver_info: {
                    bus_number: driver.bus_number,
                    driver_name: driver.driver_name,
                    route: driver.route,
                    company: driver.company_name
                }
            };
        } catch (error) {
            console.error('❌ خطأ في جلب إحصائيات السائق:', error);
            throw error;
        }
    }

    async updateLocation(busId, locationData) {
        const {
            lat,
            lng,
            speed = 0,
            passengers = 0
        } = locationData;

        try {
            // تسجيل الموقع الجديد
            await this.db.run(
                `INSERT INTO bus_locations (bus_id, location_lat, location_lng, speed, passengers, timestamp) 
                 VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
                [busId, lat, lng, speed, passengers]
            );

            // تحديث بيانات الحافلة
            await this.db.run(
                `UPDATE buses SET 
                 last_location_lat = ?, last_location_lng = ?, 
                 speed = ?, passengers = ?, last_update = CURRENT_TIMESTAMP,
                 status = 'active'
                 WHERE bus_id = ?`,
                [lat, lng, speed, passengers, busId]
            );

            // حساب المسافة إذا أمكن
            await this.calculateDistance(busId, lat, lng);

            // تسجيل حدث تحديث الموقع
            await this.logDriverEvent(busId, 'LOCATION_UPDATED', {
                lat,
                lng,
                speed,
                passengers
            });

            return { message: 'تم تحديث الموقع بنجاح' };
        } catch (error) {
            console.error('❌ خطأ في تحديث الموقع:', error);
            throw error;
        }
    }

    async calculateDistance(busId, newLat, newLng) {
        try {
            // الحصول على آخر موقع مسجل
            const lastLocation = await this.db.get(`
                SELECT location_lat, location_lng 
                FROM bus_locations 
                WHERE bus_id = ? 
                ORDER BY timestamp DESC 
                LIMIT 1, 1
            `, [busId]);

            if (lastLocation && lastLocation.location_lat && lastLocation.location_lng) {
                const distance = this.calculateDistanceBetween(
                    lastLocation.location_lat,
                    lastLocation.location_lng,
                    newLat,
                    newLng
                );

                if (distance > 0) {
                    await this.db.run(
                        'UPDATE buses SET total_distance = total_distance + ? WHERE bus_id = ?',
                        [distance, busId]
                    );
                }
            }
        } catch (error) {
            console.error('❌ خطأ في حساب المسافة:', error);
        }
    }

    calculateDistanceBetween(lat1, lng1, lat2, lng2) {
        const R = 6371; // نصف قطر الأرض بالكيلومتر
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLng/2) * Math.sin(dLng/2);
        
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    async recordFailedLoginAttempt(busNumber) {
        try {
            const currentAttempts = await this.db.get(
                'SELECT login_attempts FROM drivers WHERE bus_number = ?',
                [busNumber]
            );

            const newAttempts = (currentAttempts?.login_attempts || 0) + 1;
            
            await this.db.run(
                'UPDATE drivers SET login_attempts = ?, last_login_attempt = CURRENT_TIMESTAMP WHERE bus_number = ?',
                [newAttempts, busNumber]
            );

            // إذا تجاوزت المحاولات 5، تعطيل الحساب مؤقتاً
            if (newAttempts >= 5) {
                await this.db.run(
                    'UPDATE drivers SET login_attempts = 0 WHERE bus_number = ?',
                    [busNumber]
                );
                
                await this.logDriverEvent(busNumber, 'ACCOUNT_LOCKED', {
                    attempts: newAttempts,
                    reason: 'too_many_failed_attempts'
                });
            }
        } catch (error) {
            console.error('❌ خطأ في تسجيل محاولة الدخول الفاشلة:', error);
        }
    }

    async resetFailedLoginAttempts(busNumber) {
        try {
            await this.db.run(
                'UPDATE drivers SET login_attempts = 0 WHERE bus_number = ?',
                [busNumber]
            );
        } catch (error) {
            console.error('❌ خطأ في إعادة تعيين محاولات الدخول:', error);
        }
    }

    async updateLastLogin(busNumber) {
        try {
            await this.db.run(
                'UPDATE drivers SET last_login_attempt = NULL WHERE bus_number = ?',
                [busNumber]
            );
        } catch (error) {
            console.error('❌ خطأ في تحديث آخر دخول:', error);
        }
    }

    async logDriverEvent(busId, eventType, eventData) {
        try {
            await this.db.run(
                `INSERT INTO security_logs (event_type, event_data, timestamp) 
                 VALUES (?, ?, ?)`,
                [
                    eventType,
                    JSON.stringify({
                        busId,
                        ...eventData
                    }),
                    new Date().toISOString()
                ]
            );
        } catch (error) {
            console.error('❌ خطأ في تسجيل حدث السائق:', error);
        }
    }

    async validateCompanyLimit(companyId) {
        try {
            const company = await this.db.get(
                'SELECT max_buses FROM companies WHERE id = ? AND status = "active"',
                [companyId]
            );

            if (!company) {
                throw new Error('الشركة غير موجودة أو غير نشطة');
            }

            const currentBuses = await this.db.get(
                'SELECT COUNT(*) as count FROM buses WHERE company_id = ? AND status != "deleted"',
                [companyId]
            );

            return {
                canAddMore: currentBuses.count < company.max_buses,
                current: currentBuses.count,
                max: company.max_buses,
                remaining: Math.max(0, company.max_buses - currentBuses.count)
            };
        } catch (error) {
            console.error('❌ خطأ في التحقق من حدود الشركة:', error);
            throw error;
        }
    }

    async validateSecureToken(token) {
        // هذا مثال مبسط - في التطبيق الحقيقي سيكون هناك منطق أكثر تعقيداً
        try {
            const company = await this.db.get(
                'SELECT id, name FROM companies WHERE encryption_key = ? AND status = "active"',
                [token]
            );

            if (!company) {
                return { valid: false, reason: 'الرابط غير صالح' };
            }

            return { 
                valid: true, 
                companyId: company.id,
                companyName: company.name
            };
        } catch (error) {
            console.error('❌ خطأ في التحقق من الرابط الآمن:', error);
            return { valid: false, reason: 'خطأ في النظام' };
        }
    }

    async getActiveDrivers(companyId = null) {
        try {
            let query = `
                SELECT d.*, b.driver_name, b.route, b.last_location_lat, b.last_location_lng,
                       b.speed, b.passengers, b.last_update, c.name as company_name
                FROM drivers d 
                JOIN buses b ON d.bus_id = b.bus_id
                JOIN companies c ON b.company_id = c.id
                WHERE b.status = 'active' 
                AND b.last_update > datetime('now', '-5 minutes')
                AND c.status = 'active'
            `;
            const params = [];

            if (companyId) {
                query += ' AND b.company_id = ?';
                params.push(companyId);
            }

            query += ' ORDER BY b.last_update DESC';

            const activeDrivers = await this.db.all(query, params);
            return activeDrivers;
        } catch (error) {
            console.error('❌ خطأ في جلب السائقين النشطين:', error);
            throw error;
        }
    }
}

// إنشاء instance واحدة من نموذج السائق
const driverModel = new Driver();

// تصدير الدوال للاستخدام
module.exports = {
    // العمليات الأساسية
    registerDriver: (driverData) => driverModel.register(driverData),
    authenticateDriver: (busNumber, password) => driverModel.authenticate(busNumber, password),
    getDriver: (busId) => driverModel.getByBusId(busId),
    getDriverByBusNumber: (busNumber) => driverModel.getByBusNumber(busNumber),
    updateDriver: (busNumber, updateData) => driverModel.update(busNumber, updateData),
    deleteDriver: (busNumber) => driverModel.delete(busNumber),
    
    // الاستعلامات
    getDriversByCompany: (companyId, filter) => driverModel.getAllByCompany(companyId, filter),
    getDriverStatistics: (busNumber) => driverModel.getDriverStatistics(busNumber),
    getActiveDrivers: (companyId) => driverModel.getActiveDrivers(companyId),
    
    // الموقع والتتبع
    updateDriverLocation: (busId, locationData) => driverModel.updateLocation(busId, locationData),
    
    // الأمان
    validateSecureToken: (token) => driverModel.validateSecureToken(token)
};