const helmet = require('helmet');

// إعدادات أمان headers متقدمة
const securityHeaders = helmet({
    // Content Security Policy
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: [
                "'self'", 
                "'unsafe-inline'", 
                "https://cdnjs.cloudflare.com",
                "https://fonts.googleapis.com"
            ],
            scriptSrc: [
                "'self'", 
                "'unsafe-inline'", 
                "https://cdnjs.cloudflare.com", 
                "https://unpkg.com"
            ],
            connectSrc: [
                "'self'", 
                "ws:", 
                "wss:", 
                "https://*.tile.openstreetmap.org",
                "stun:stun.l.google.com:19302"
            ],
            imgSrc: [
                "'self'", 
                "data:", 
                "https:",
                "https://*.tile.openstreetmap.org"
            ],
            fontSrc: [
                "'self'", 
                "https://fonts.gstatic.com",
                "https://cdnjs.cloudflare.com"
            ],
            objectSrc: ["'none'"],
            mediaSrc: ["'self'"],
            frameSrc: ["'none'"],
            childSrc: ["'none'"],
            formAction: ["'self'"],
            baseUri: ["'self'"]
        }
    },
    
    // HTTP Strict Transport Security
    hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true
    },
    
    // X-Frame-Options
    frameguard: {
        action: 'deny'
    },
    
    // X-Content-Type-Options
    noSniff: true,
    
    // X-Download-Options
    ieNoOpen: true,
    
    // Referrer Policy
    referrerPolicy: {
        policy: 'strict-origin-when-cross-origin'
    },
    
    // X-XSS-Protection
    xssFilter: true
});

// إعدادات أمان إضافية
const additionalSecurityHeaders = (req, res, next) => {
    // منع تخزين cache للصفحات الحساسة
    if (req.path.includes('dashboard') || req.path.includes('admin')) {
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        res.setHeader('Surrogate-Control', 'no-store');
    }
    
    // إضافة header لمنع MIME sniffing
    res.setHeader('X-Content-Type-Options', 'nosniff');
    
    // إضافة header لمنع clickjacking
    res.setHeader('X-Frame-Options', 'DENY');
    
    // إضافة header لسياسة referrer
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    
    // إضافة header لسياسة الأذونات
    res.setHeader('Permissions-Policy', 
        'geolocation=(), microphone=(), camera=(), payment=()'
    );
    
    // إضافة header لتعزيز الأمان
    res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
    
    next();
};

// Middleware للتحقق من أمان الطلبات
const requestSecurityMiddleware = (req, res, next) => {
    const securityChecks = {
        validMethods: ['GET', 'POST', 'PUT', 'DELETE'].includes(req.method),
        validContentType: req.is('application/json') || req.is('text/html') || req.is('text/plain'),
        reasonableSize: req.get('Content-Length') < 10 * 1024 * 1024, // 10MB كحد أقصى
        safePath: !req.path.includes('..') && !req.path.includes('//')
    };
    
    const allChecksPass = Object.values(securityChecks).every(check => check);
    
    if (!allChecksPass) {
        console.warn('🚨 طلب مشبوه تم رفضه:', {
            ip: req.ip,
            method: req.method,
            path: req.path,
            userAgent: req.get('User-Agent'),
            checks: securityChecks
        });
        
        return res.status(400).json({ 
            error: 'طلب غير صالح',
            code: 'SECURITY_VIOLATION'
        });
    }
    
    next();
};

// Middleware للتحقق من CSRF token
const csrfProtection = (req, res, next) => {
    const skipPaths = ['/api/public', '/static', '/health'];
    
    if (skipPaths.some(path => req.path.startsWith(path))) {
        return next();
    }
    
    if (req.method === 'POST' || req.method === 'PUT' || req.method === 'DELETE') {
        const csrfToken = req.headers['x-csrf-token'] || req.body._csrf;
        
        if (!csrfToken || !isValidCSRFToken(csrfToken)) {
            return res.status(403).json({
                error: 'رمز الأمان غير صالح أو منتهي الصلاحية',
                code: 'CSRF_TOKEN_INVALID'
            });
        }
    }
    
    next();
};

// دالة التحقق من CSRF token
function isValidCSRFToken(token) {
    if (typeof token !== 'string' || token.length !== 64) {
        return false;
    }
    
    // يمكن إضافة منطق أكثر تعقيداً للتحقق من التوكن
    return /^[a-f0-9]{64}$/.test(token);
}

// Middleware لمراقبة الطلبات المشبوهة
const threatDetectionMiddleware = (req, res, next) => {
    const suspiciousPatterns = [
        /(?:\.\.\/|\.\.\\|%2e%2e%2f)/i, // Directory traversal
        /<script|javascript:/i, // XSS attempts
        /union.*select|insert.*into|drop.*table/i, // SQL injection
        /eval\(|exec\(|system\(/i, // Command injection
        /\/\.env|\/config|\/backup/i // Sensitive file access
    ];
    
    const requestString = JSON.stringify({
        path: req.path,
        query: req.query,
        body: req.body,
        headers: req.headers
    }).toLowerCase();
    
    const detectedThreats = suspiciousPatterns.filter(pattern => 
        pattern.test(requestString)
    );
    
    if (detectedThreats.length > 0) {
        console.warn('🚨 كشف تهديد أمني:', {
            ip: req.ip,
            path: req.path,
            threats: detectedThreats.map(p => p.source),
            userAgent: req.get('User-Agent')
        });
        
        // تسجيل الحدث الأمني
        logSecurityEvent('THREAT_DETECTED', {
            ip: req.ip,
            path: req.path,
            threats: detectedThreats.length,
            userAgent: req.get('User-Agent')
        });
        
        return res.status(403).json({
            error: 'تم رفض الطلب لأسباب أمنية',
            code: 'THREAT_DETECTED'
        });
    }
    
    next();
};

// دالة تسجيل الأحداث الأمنية
function logSecurityEvent(eventType, eventData) {
    const timestamp = new Date().toISOString();
    console.log(`🔒 [${timestamp}] ${eventType}:`, eventData);
    
    // هنا يمكن إضافة منطق لحفظ الأحداث في قاعدة البيانات
    // أو إرسال إشعارات للمشرفين
}

module.exports = {
    securityHeaders,
    additionalSecurityHeaders,
    requestSecurityMiddleware,
    csrfProtection,
    threatDetectionMiddleware,
    logSecurityEvent
};