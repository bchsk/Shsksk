const WebSocket = require('ws');
const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const { v4: uuidv4 } = require('uuid');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

// تحميل إعدادات الأمان
const securityHeaders = require('./config/security-headers');
const { initSecurity, detectThreats, logSecurityEvent, validateInput } = require('./utils/security');
const { startPerformanceMonitoring, getPerformanceMetrics } = require('./utils/performance-monitor');
const { initEmergencyManager, handleSTUNFailure, switchToBackupSTUN } = require('./utils/emergency-manager');

// تطبيق إعدادات الأمان
app.use(securityHeaders.securityHeaders);
app.use(securityHeaders.additionalSecurityHeaders);
app.use(securityHeaders.requestSecurityMiddleware);
app.use(securityHeaders.csrfProtection);
app.use(securityHeaders.threatDetectionMiddleware);

app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
            scriptSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com", "https://unpkg.com"],
            connectSrc: ["'self'", "ws:", "wss:", "https://*.tile.openstreetmap.org"],
            imgSrc: ["'self'", "data:", "https://*.tile.openstreetmap.org"]
        }
    },
    hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true
    }
}));

// Rate limiting متقدم
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 دقيقة
    max: 5, // 5 محاولات كحد أقصى
    message: 'تم تجاوز عدد المحاولات المسموح بها، يرجى المحاولة بعد 15 دقيقة',
    handler: (req, res) => {
        securityHeaders.logSecurityEvent('RATE_LIMIT_EXCEEDED', {
            ip: req.ip,
            path: req.path,
            userAgent: req.get('User-Agent')
        });
        res.status(429).json({ error: 'تم تجاوز عدد المحاولات المسموح بها' });
    }
});

app.use(express.static('public'));
app.use(express.json({ limit: '10mb' }));

// تطبيق rate limiting على صفحات الدخول
app.use('/super-admin-login.html', loginLimiter);
app.use('/company-login.html', loginLimiter);
app.use('/driver-login.html', loginLimiter);

const server = app.listen(PORT, () => {
    console.log(`🚀 الخادم يعمل على port ${PORT}`);
    console.log(`🔒 نظام تتبع الحافلات يعمل بدون P2P`);
});

// WebSocket Server مع ضغط متقدم
const wss = new WebSocket.Server({ 
    server,
    perMessageDeflate: {
        zlibDeflateOptions: {
            chunkSize: 1024,
            memLevel: 7,
            level: 3
        },
        zlibInflateOptions: {
            chunkSize: 10 * 1024
        },
        clientNoContextTakeover: true,
        serverNoContextTakeover: true,
        serverMaxWindowBits: 10,
        concurrencyLimit: 10,
        threshold: 1024
    }
});

// تهيئة أنظمة الأمان والطوارئ
initSecurity();
startPerformanceMonitoring();
initEmergencyManager();

// المشرف الرئيسي
const SUPER_ADMIN = {
    username: 'admin',
    password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' // admin123
};

// تخزين الجلسات النشطة مع انتهاء الصلاحية
const activeSessions = new Map();
const activeConnections = new Map();
const statistics = {
    totalCompanies: 0,
    activeBuses: 0,
    stoppedBuses: 0,
    totalDistance: 0,
    messagesProcessed: 0,
    securityEvents: 0
};

// تخزين بيانات النظام
const systemData = {
    companies: [],
    buses: [],
    drivers: []
};

// تهيئة قاعدة البيانات
let db;
async function initializeDatabase() {
    db = await open({
        filename: './bus_tracking.db',
        driver: sqlite3.Database
    });

    // تحسينات SSD متقدمة
    await db.exec(`
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous = NORMAL;
        PRAGMA cache_size = -64000;
        PRAGMA temp_store = memory;
        PRAGMA mmap_size = 30000000000;
        PRAGMA busy_timeout = 5000;
        PRAGMA auto_vacuum = INCREMENTAL;
        PRAGMA optimize;
        PRAGMA foreign_keys = ON;
        PRAGMA secure_delete = ON;
    `);

    console.log('✅ قاعدة البيانات مهيأة مع تحسينات SSD متقدمة');
    await loadSystemData();
}

async function loadSystemData() {
    try {
        // تحميل الشركات
        systemData.companies = await db.all(`
            SELECT c.*, 
                   (SELECT COUNT(*) FROM buses WHERE company_id = c.id AND status != 'deleted') as bus_count,
                   (SELECT COUNT(*) FROM buses WHERE company_id = c.id AND status = 'active') as active_buses
            FROM companies c 
            WHERE c.status != 'deleted'
        `);

        // تحميل الحافلات
        systemData.buses = await db.all(`
            SELECT b.*, c.name as company_name
            FROM buses b
            JOIN companies c ON b.company_id = c.id
            WHERE b.status != 'deleted'
        `);

        // تحميل السائقين
        systemData.drivers = await db.all(`
            SELECT d.*, b.driver_name, b.route, b.bus_id, c.name as company_name
            FROM drivers d
            JOIN buses b ON d.bus_id = b.bus_id
            JOIN companies c ON b.company_id = c.id
        `);

        statistics.totalCompanies = systemData.companies.length;
        statistics.activeBuses = systemData.buses.filter(b => b.status === 'active').length;
        statistics.stoppedBuses = systemData.buses.filter(b => b.status === 'stopped').length;
        
        console.log(`✅ تم تحميل بيانات النظام: ${systemData.companies.length} شركة، ${systemData.buses.length} حافلة`);
    } catch (error) {
        console.error('❌ خطأ في تحميل بيانات النظام:', error);
    }
}

// تنظيف الجلسات المنتهية كل دقيقة
setInterval(() => {
    const now = Date.now();
    for (const [sessionId, session] of activeSessions.entries()) {
        if (now - session.lastActivity > 24 * 60 * 60 * 1000) { // 24 ساعة
            activeSessions.delete(sessionId);
            securityHeaders.logSecurityEvent('SESSION_EXPIRED', { sessionId, username: session.username });
        }
    }
}, 60000);

wss.on('connection', (ws, req) => {
    const clientId = generateUUID();
    const clientIp = req.socket.remoteAddress;
    const userAgent = req.headers['user-agent'];
    
    // كشف التهديدات الأولي
    const threatLevel = detectThreats(clientIp, userAgent);
    if (threatLevel > 7) {
        ws.close(1008, 'Connection blocked by security system');
        securityHeaders.logSecurityEvent('HIGH_THREAT_BLOCKED', { clientIp, userAgent, threatLevel });
        return;
    }

    console.log(`🔗 عميل جديد: ${clientId} من ${clientIp}`);
    securityHeaders.logSecurityEvent('CLIENT_CONNECTED', { clientId, clientIp, userAgent });

    ws.clientId = clientId;
    ws.ip = clientIp;
    ws.connectTime = Date.now();

    activeConnections.set(clientId, {
        ws,
        ip: clientIp,
        userAgent,
        connectTime: Date.now(),
        lastActivity: Date.now()
    });

    ws.on('message', async (message) => {
        try {
            ws.lastActivity = Date.now();
            activeConnections.get(clientId).lastActivity = Date.now();
            
            const data = JSON.parse(message);
            statistics.messagesProcessed++;
            
            // تحقق من صحة المدخلات
            const validationResult = validateInput(data);
            if (!validationResult.valid) {
                ws.send(JSON.stringify({
                    type: 'error',
                    message: 'بيانات غير صالحة',
                    details: validationResult.errors
                }));
                securityHeaders.logSecurityEvent('INVALID_INPUT', { clientId, errors: validationResult.errors });
                return;
            }

            await handleMessage(ws, data, clientId);
        } catch (error) {
            console.error('❌ خطأ في parsing الرسالة:', error);
            securityHeaders.logSecurityEvent('MESSAGE_PARSE_ERROR', { clientId, error: error.message });
        }
    });

    ws.on('close', (code, reason) => {
        cleanupConnection(ws);
        console.log(`🔌 عميل منقطع: ${clientId} - ${code} ${reason}`);
        securityHeaders.logSecurityEvent('CLIENT_DISCONNECTED', { clientId, code, reason: reason.toString() });
    });

    ws.on('error', (error) => {
        console.error('💥 خطأ WebSocket:', error);
        securityHeaders.logSecurityEvent('WEBSOCKET_ERROR', { clientId, error: error.message });
        cleanupConnection(ws);
    });
});

async function handleMessage(ws, data, clientId) {
    // تحديث نشاط الجلسة
    if (ws.sessionId && activeSessions.has(ws.sessionId)) {
        activeSessions.get(ws.sessionId).lastActivity = Date.now();
    }

    switch (data.type) {
        case 'super_admin_login':
            await handleSuperAdminLogin(ws, data, clientId);
            break;
        case 'company_admin_login':
            await handleCompanyAdminLogin(ws, data, clientId);
            break;
        case 'driver_login':
            await handleDriverLogin(ws, data, clientId);
            break;
        case 'create_company':
            await handleCreateCompany(ws, data);
            break;
        case 'get_companies':
            await handleGetCompanies(ws);
            break;
        case 'get_dashboard_data':
            await sendDashboardData(ws, data.userType, data.companyId);
            break;
        case 'get_bus_route':
            await sendBusRoute(ws, data.busId);
            break;
        case 'location_update':
            await updateBusLocation(ws, data, clientId);
            break;
        case 'send_message':
            await handleSendMessage(ws, data, clientId);
            break;
        case 'get_messages':
            await sendMessages(ws, data.busId, data.userType);
            break;
        case 'ping':
            handlePing(ws, data);
            break;
        case 'emergency_switch_stun':
            handleSTUNSwitch(data.reason);
            break;
        case 'get_security_logs':
            await sendSecurityLogs(ws);
            break;
        default:
            ws.send(JSON.stringify({ type: 'error', message: 'نوع الرسالة غير معروف' }));
    }
}

async function handleSuperAdminLogin(ws, data, clientId) {
    const { username, password, csrfToken } = data;
    
    // التحقق من CSRF token
    if (!validateCSRFToken(csrfToken)) {
        ws.send(JSON.stringify({
            type: 'login_error',
            message: 'رمز الأمان غير صالح'
        }));
        securityHeaders.logSecurityEvent('CSRF_VALIDATION_FAILED', { clientId, username });
        return;
    }

    if (username === SUPER_ADMIN.username && await bcrypt.compare(password, SUPER_ADMIN.password)) {
        const sessionId = generateUUID();
        const csrfToken = generateCSRFToken();
        
        activeSessions.set(sessionId, {
            userType: 'super_admin',
            username: username,
            loginTime: new Date(),
            lastActivity: Date.now(),
            csrfToken: csrfToken
        });

        ws.userType = 'super_admin';
        ws.sessionId = sessionId;

        ws.send(JSON.stringify({
            type: 'super_admin_login_success',
            sessionId: sessionId,
            csrfToken: csrfToken
        }));
        
        console.log(`✅ مشرف رئيسي مسجل: ${username}`);
        securityHeaders.logSecurityEvent('SUPER_ADMIN_LOGIN_SUCCESS', { clientId, username });
    } else {
        ws.send(JSON.stringify({
            type: 'login_error',
            message: 'بيانات الدخول غير صحيحة'
        }));
        securityHeaders.logSecurityEvent('LOGIN_FAILED', { clientId, username, reason: 'invalid_credentials' });
    }
}

async function handleCompanyAdminLogin(ws, data, clientId) {
    const { username, password, csrfToken } = data;
    
    if (!validateCSRFToken(csrfToken)) {
        ws.send(JSON.stringify({
            type: 'login_error',
            message: 'رمز الأمان غير صالح'
        }));
        return;
    }

    try {
        const admin = await db.get(
            `SELECT ca.*, c.name as company_name, c.max_buses, c.status as company_status, c.uuid as company_uuid
             FROM company_admins ca 
             JOIN companies c ON ca.company_id = c.id 
             WHERE ca.username = ?`,
            [username]
        );

        if (admin && admin.company_status === 'active' && await bcrypt.compare(password, admin.password)) {
            const sessionId = generateUUID();
            const csrfToken = generateCSRFToken();
            
            activeSessions.set(sessionId, {
                userType: 'company_admin',
                companyId: admin.company_id,
                username: username,
                loginTime: new Date(),
                lastActivity: Date.now(),
                csrfToken: csrfToken
            });

            ws.userType = 'company_admin';
            ws.sessionId = sessionId;
            ws.companyId = admin.company_id;

            const busCount = await db.get(
                'SELECT COUNT(*) as count FROM buses WHERE company_id = ? AND status != "deleted"',
                [admin.company_id]
            );

            ws.send(JSON.stringify({
                type: 'company_admin_login_success',
                sessionId: sessionId,
                csrfToken: csrfToken,
                companyData: {
                    id: admin.company_id,
                    uuid: admin.company_uuid,
                    name: admin.company_name,
                    maxBuses: admin.max_buses,
                    currentBuses: busCount.count
                }
            }));
            
            console.log(`✅ مدير شركة مسجل: ${username} - ${admin.company_name}`);
            securityHeaders.logSecurityEvent('COMPANY_ADMIN_LOGIN_SUCCESS', { clientId, username, companyId: admin.company_id });
        } else {
            ws.send(JSON.stringify({
                type: 'login_error',
                message: 'بيانات الدخول غير صحيحة أو الشركة غير نشطة'
            }));
            securityHeaders.logSecurityEvent('COMPANY_LOGIN_FAILED', { clientId, username });
        }
    } catch (error) {
        console.error('❌ خطأ في تسجيل مدير الشركة:', error);
        ws.send(JSON.stringify({
            type: 'login_error',
            message: 'خطأ في النظام'
        }));
        securityHeaders.logSecurityEvent('COMPANY_LOGIN_ERROR', { clientId, username, error: error.message });
    }
}

async function handleDriverLogin(ws, data, clientId) {
    const { busNumber, password, companyUrl } = data;
    
    try {
        const driver = await db.get(
            `SELECT d.*, b.bus_id, b.driver_name, b.route, c.id as company_id, c.status as company_status,
                    c.uuid as company_uuid, b.uuid as bus_uuid
             FROM drivers d 
             JOIN buses b ON d.bus_id = b.bus_id
             JOIN companies c ON b.company_id = c.id
             WHERE d.bus_number = ? AND c.status = 'active' AND b.status != 'deleted'`,
            [busNumber]
        );

        if (driver && await bcrypt.compare(password, driver.password)) {
            ws.driverData = driver;
            ws.userType = 'driver';
            ws.busId = driver.bus_id;
            ws.companyId = driver.company_id;

            // تحديث حالة السائق
            await db.run(
                'UPDATE buses SET status = "active", last_update = datetime("now") WHERE bus_id = ?',
                [driver.bus_id]
            );

            // إنشاء رابط آمن للسائق
            const secureLink = generateSecureLink(driver.bus_uuid);

            ws.send(JSON.stringify({
                type: 'login_success',
                driverData: driver,
                secureLink: secureLink,
                timestamp: Date.now()
            }));
            
            console.log(`✅ سائق مسجل: ${driver.driver_name} - ${driver.bus_id}`);
            securityHeaders.logSecurityEvent('DRIVER_LOGIN_SUCCESS', { clientId, busId: driver.bus_id, driverName: driver.driver_name });
        } else {
            ws.send(JSON.stringify({
                type: 'login_error',
                message: 'رقم الحافلة أو كلمة السر غير صحيحة'
            }));
            securityHeaders.logSecurityEvent('DRIVER_LOGIN_FAILED', { clientId, busNumber });
        }
    } catch (error) {
        console.error('❌ خطأ في تسجيل السائق:', error);
        ws.send(JSON.stringify({
            type: 'login_error',
            message: 'خطأ في النظام'
        }));
        securityHeaders.logSecurityEvent('DRIVER_LOGIN_ERROR', { clientId, busNumber, error: error.message });
    }
}

async function handleCreateCompany(ws, data) {
    try {
        const { companyName, maxBuses, adminUsername, adminPassword, csrfToken } = data;
        
        if (!validateCSRFToken(csrfToken)) {
            ws.send(JSON.stringify({
                type: 'company_created',
                success: false,
                message: 'رمز الأمان غير صالح'
            }));
            return;
        }

        // إنشاء الشركة باستخدام النموذج
        const result = await companyModel.createCompany({
            name: companyName,
            maxBuses: parseInt(maxBuses),
            adminUsername: adminUsername,
            adminPassword: adminPassword,
            backupInterval: 6,
            status: 'active'
        });

        await loadSystemData(); // تحديث بيانات النظام
        
        ws.send(JSON.stringify({
            type: 'company_created',
            success: true,
            message: 'تم إنشاء الشركة بنجاح',
            company: result
        }));
        
    } catch (error) {
        console.error('❌ خطأ في إنشاء الشركة:', error);
        ws.send(JSON.stringify({
            type: 'company_created',
            success: false,
            message: error.message
        }));
    }
}

async function handleGetCompanies(ws) {
    try {
        const companies = await companyModel.getAllCompanies({});
        
        ws.send(JSON.stringify({
            type: 'companies_data',
            companies: companies
        }));
    } catch (error) {
        console.error('❌ خطأ في جلب الشركات:', error);
        ws.send(JSON.stringify({
            type: 'companies_data',
            companies: [],
            error: error.message
        }));
    }
}

async function sendDashboardData(ws, userType, companyId = null) {
    try {
        let dashboardData = {
            type: 'dashboard_data',
            statistics: {
                totalCompanies: statistics.totalCompanies,
                activeBuses: statistics.activeBuses,
                stoppedBuses: statistics.stoppedBuses,
                totalDistance: statistics.totalDistance,
                messagesProcessed: statistics.messagesProcessed,
                securityEvents: statistics.securityEvents
            },
            buses: [],
            stoppedBuses: [],
            securityAlerts: [],
            stunStatus: { servers: [{ url: 'stun:localhost:3478', active: true }] }
        };

        if (userType === 'super_admin') {
            // عرض جميع الحافلات للمشرف الرئيسي
            dashboardData.buses = systemData.buses
                .filter(b => b.status === 'active')
                .map(b => ({
                    busId: b.bus_id,
                    driverName: b.driver_name,
                    route: b.route,
                    companyName: b.company_name,
                    location: b.last_location_lat ? {
                        lat: b.last_location_lat,
                        lng: b.last_location_lng
                    } : null,
                    speed: b.speed,
                    passengers: b.passengers,
                    totalDistance: b.total_distance,
                    lastUpdate: b.last_update,
                    isMoving: b.speed > 2
                }));

            dashboardData.stoppedBuses = systemData.buses
                .filter(b => b.status === 'stopped')
                .map(b => ({
                    busId: b.bus_id,
                    driverName: b.driver_name,
                    route: b.route,
                    companyName: b.company_name,
                    location: b.last_location_lat ? {
                        lat: b.last_location_lat,
                        lng: b.last_location_lng
                    } : null,
                    speed: 0,
                    passengers: 0,
                    totalDistance: b.total_distance,
                    lastUpdate: b.last_update,
                    isMoving: false
                }));

            // إشعارات أمنية وهمية للاختبار
            dashboardData.securityAlerts = [
                {
                    title: 'فشل تسجيل دخول',
                    message: 'محاولة تسجيل دخول فاشلة من IP: 192.168.1.100',
                    timestamp: Date.now() - 300000,
                    severity: 'low'
                }
            ];

        } else if (userType === 'company_admin' && companyId) {
            // عرض حافلات الشركة فقط
            const companyBuses = systemData.buses.filter(b => b.company_id === companyId);
            
            dashboardData.buses = companyBuses
                .filter(b => b.status === 'active')
                .map(b => ({
                    busId: b.bus_id,
                    driverName: b.driver_name,
                    route: b.route,
                    companyName: b.company_name,
                    location: b.last_location_lat ? {
                        lat: b.last_location_lat,
                        lng: b.last_location_lng
                    } : null,
                    speed: b.speed,
                    passengers: b.passengers,
                    totalDistance: b.total_distance,
                    lastUpdate: b.last_update,
                    isMoving: b.speed > 2
                }));

            dashboardData.stoppedBuses = companyBuses
                .filter(b => b.status === 'stopped')
                .map(b => ({
                    busId: b.bus_id,
                    driverName: b.driver_name,
                    route: b.route,
                    companyName: b.company_name,
                    location: b.last_location_lat ? {
                        lat: b.last_location_lat,
                        lng: b.last_location_lng
                    } : null,
                    speed: 0,
                    passengers: 0,
                    totalDistance: b.total_distance,
                    lastUpdate: b.last_update,
                    isMoving: false
                }));

            dashboardData.statistics.totalCompanies = 1;
            dashboardData.statistics.activeBuses = dashboardData.buses.length;
            dashboardData.statistics.stoppedBuses = dashboardData.stoppedBuses.length;
        }

        ws.send(JSON.stringify(dashboardData));
    } catch (error) {
        console.error('❌ خطأ في إرسال بيانات اللوحة:', error);
        ws.send(JSON.stringify({
            type: 'error',
            message: 'خطأ في تحميل البيانات'
        }));
    }
}

async function sendBusRoute(ws, busId) {
    try {
        const locations = await db.all(`
            SELECT location_lat as lat, location_lng as lng, timestamp
            FROM bus_locations 
            WHERE bus_id = ? 
            ORDER BY timestamp DESC 
            LIMIT 50
        `, [busId]);

        ws.send(JSON.stringify({
            type: 'bus_route',
            busId: busId,
            route: locations.map(loc => ({ lat: loc.lat, lng: loc.lng })),
            count: locations.length
        }));
    } catch (error) {
        console.error('❌ خطأ في إرسال مسار الحافلة:', error);
        ws.send(JSON.stringify({
            type: 'error',
            message: 'خطأ في تحميل المسار'
        }));
    }
}

async function updateBusLocation(ws, data, clientId) {
    const { busId, location, speed, passengers } = data;
    
    try {
        const previousLocation = await db.get(
            'SELECT location_lat, location_lng FROM bus_locations WHERE bus_id = ? ORDER BY timestamp DESC LIMIT 1, 1',
            [busId]
        );

        await db.run(
            `INSERT INTO bus_locations (bus_id, location_lat, location_lng, speed, passengers, timestamp) 
             VALUES (?, ?, ?, ?, ?, datetime('now'))`,
            [busId, location.lat, location.lng, speed, passengers]
        );

        await db.run(
            `UPDATE buses SET 
             last_location_lat = ?, last_location_lng = ?, 
             speed = ?, passengers = ?, last_update = datetime('now'),
             status = 'active'
             WHERE bus_id = ?`,
            [location.lat, location.lng, speed, passengers, busId]
        );

        if (previousLocation && speed > 2) {
            const distance = calculateDistance(
                { lat: previousLocation.location_lat, lng: previousLocation.location_lng },
                location
            );
            
            await db.run(
                'UPDATE buses SET total_distance = total_distance + ? WHERE bus_id = ?',
                [distance, busId]
            );

            statistics.totalDistance += distance;
        }

        // تحديث بيانات النظام في الذاكرة
        const busIndex = systemData.buses.findIndex(b => b.bus_id === busId);
        if (busIndex !== -1) {
            systemData.buses[busIndex].last_location_lat = location.lat;
            systemData.buses[busIndex].last_location_lng = location.lng;
            systemData.buses[busIndex].speed = speed;
            systemData.buses[busIndex].passengers = passengers;
            systemData.buses[busIndex].last_update = new Date().toISOString();
            systemData.buses[busIndex].status = 'active';
        }

        const updateData = {
            type: 'bus_updated',
            busId,
            location,
            speed: speed,
            passengers: passengers,
            isMoving: speed > 2,
            driverName: data.driverName,
            route: data.route,
            timestamp: Date.now()
        };

        // إرسال التحديث لجميع المشرفين
        broadcastToAdmins(updateData);
        
        // تحديث مراقبة الأداء
        const performanceMetrics = getPerformanceMetrics();
        if (performanceMetrics) {
            updateData.performance = performanceMetrics;
        }
        
    } catch (error) {
        console.error('❌ خطأ في تحديث الموقع:', error);
        securityHeaders.logSecurityEvent('LOCATION_UPDATE_ERROR', { clientId, busId, error: error.message });
    }
}

async function handleSendMessage(ws, data, clientId) {
    try {
        const { busId, message, senderType, messageType = 'text' } = data;
        
        await db.run(
            `INSERT INTO messages (bus_id, sender_id, message, message_type, timestamp) 
             VALUES (?, ?, ?, ?, datetime('now'))`,
            [busId, senderType, message, messageType]
        );

        const messageData = {
            type: 'new_message',
            busId,
            message,
            senderType,
            messageType,
            timestamp: Date.now()
        };

        // إرسال الرسالة للمشرفين المعنيين
        broadcastToAdmins(messageData);
        
        // إرسال الرسالة للسائق إذا كان المشرف هو المرسل
        if (senderType === 'admin') {
            broadcastToDriver(busId, messageData);
        }

        securityHeaders.logSecurityEvent('MESSAGE_SENT', { 
            clientId, 
            busId, 
            senderType, 
            messageType 
        });
        
    } catch (error) {
        console.error('❌ خطأ في إرسال الرسالة:', error);
        securityHeaders.logSecurityEvent('MESSAGE_SEND_ERROR', { 
            clientId, 
            error: error.message 
        });
    }
}

async function sendMessages(ws, busId, userType) {
    try {
        const messages = await db.all(`
            SELECT * FROM messages 
            WHERE bus_id = ? 
            ORDER BY timestamp DESC 
            LIMIT 50
        `, [busId]);

        ws.send(JSON.stringify({
            type: 'messages_data',
            messages: messages,
            busId: busId
        }));
    } catch (error) {
        console.error('❌ خطأ في إرسال الرسائل:', error);
        ws.send(JSON.stringify({
            type: 'error',
            message: 'خطأ في تحميل الرسائل'
        }));
    }
}

async function sendSecurityLogs(ws) {
    try {
        const logs = await db.all(`
            SELECT * FROM security_logs 
            ORDER BY timestamp DESC 
            LIMIT 100
        `);

        ws.send(JSON.stringify({
            type: 'security_logs_data',
            logs: logs
        }));
    } catch (error) {
        console.error('❌ خطأ في إرسال سجلات الأمان:', error);
        ws.send(JSON.stringify({
            type: 'error',
            message: 'خطأ في تحميل سجلات الأمان'
        }));
    }
}

function handlePing(ws, data) {
    const response = {
        type: 'pong',
        timestamp: Date.now(),
        serverTime: Date.now(),
        performance: getPerformanceMetrics()
    };
    
    ws.send(JSON.stringify(response));
}

function handleSTUNSwitch(reason) {
    console.log(`🔄 تبديل خادم STUN: ${reason}`);
    switchToBackupSTUN(reason);
    
    // إشعار جميع العملاء
    broadcastToAll({
        type: 'stun_switch',
        reason: reason,
        timestamp: Date.now()
    });
}

function broadcastToAll(message) {
    const messageStr = JSON.stringify(message);
    let sentCount = 0;
    
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(messageStr);
            sentCount++;
        }
    });
    
    return sentCount;
}

function broadcastToAdmins(message) {
    const messageStr = JSON.stringify(message);
    let sentCount = 0;
    
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN && 
            (client.userType === 'super_admin' || client.userType === 'company_admin')) {
            client.send(messageStr);
            sentCount++;
        }
    });
    
    return sentCount;
}

function broadcastToDriver(busId, message) {
    const messageStr = JSON.stringify(message);
    let sentCount = 0;
    
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN && 
            client.userType === 'driver' && 
            client.busId === busId) {
            client.send(messageStr);
            sentCount++;
        }
    });
    
    return sentCount;
}

function generateUUID() {
    return uuidv4();
}

function generateCSRFToken() {
    return crypto.randomBytes(32).toString('hex');
}

function validateCSRFToken(token) {
    if (!token) return false;
    
    for (const [sessionId, session] of activeSessions.entries()) {
        if (session.csrfToken === token) {
            return true;
        }
    }
    return false;
}

function generateSecureLink(busUUID) {
    return `/driver-login.html?token=${busUUID}&expires=${Date.now() + 24 * 60 * 60 * 1000}`;
}

function calculateDistance(loc1, loc2) {
    if (!loc1 || !loc2) return 0;
    const R = 6371;
    const dLat = (loc2.lat - loc1.lat) * Math.PI / 180;
    const dLon = (loc2.lng - loc1.lng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(loc1.lat * Math.PI / 180) * Math.cos(loc2.lat * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function cleanupConnection(ws) {
    if (ws.busId) {
        db.run(
            'UPDATE buses SET status = "stopped", last_update = datetime("now") WHERE bus_id = ?',
            [ws.busId]
        ).catch(console.error);
    }

    if (ws.sessionId) {
        activeSessions.delete(ws.sessionId);
    }

    if (ws.clientId) {
        activeConnections.delete(ws.clientId);
    }
}

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'super-admin-login.html'));
});

app.get('/super-admin-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'super-admin-dashboard.html'));
});

app.get('/company-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'company-dashboard.html'));
});

app.get('/driver', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'driver-login.html'));
});

app.get('/driver-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'driver-dashboard.html'));
});

// التهيئة
async function startServer() {
    await initializeDatabase();
    
    // التحقق من وجود بيانات أولية
    const companiesCount = await db.get('SELECT COUNT(*) as count FROM companies');
    if (companiesCount.count === 0) {
        console.log('🔧 جاري تهيئة البيانات الافتراضية...');
        // يمكن إضافة بيانات افتراضية هنا
    }

    console.log('✅ نظام تتبع الحافلات يعمل بدون P2P!');
    console.log('🛡️  نظام أمان متكامل مع كشف تهديدات');
    console.log('👑 المشرف الرئيسي: http://localhost:3000/super-admin-login.html');
    console.log('🏢 مديري الشركات: http://localhost:3000/company-login.html');
    console.log('🚍 السائقين: http://localhost:3000/driver-login.html');
}

startServer().catch(console.error);

// تصدير الدوال للاختبار
module.exports = {
    app,
    wss,
    activeSessions,
    activeConnections,
    statistics,
    systemData,
    generateUUID,
    generateCSRFToken,
    initializeDatabase
};