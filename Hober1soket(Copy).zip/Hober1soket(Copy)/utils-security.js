const crypto = require('crypto');
const { initializeDatabase } = require('../config/database');

class SecurityManager {
    constructor() {
        this.threatLevel = 0;
        this.suspiciousIPs = new Set();
        this.failedAttempts = new Map();
        this.securityEvents = [];
        this.db = null;
        
        this.init();
    }

    async init() {
        this.db = await initializeDatabase();
        this.loadThreatData();
        setInterval(() => this.cleanupOldData(), 60 * 60 * 1000); // كل ساعة
    }

    async loadThreatData() {
        try {
            // تحميل IPs المشبوهة من قاعدة البيانات
            const suspiciousIPs = await this.db.all(
                'SELECT ip_address FROM security_logs WHERE severity = "high" GROUP BY ip_address'
            );
            
            suspiciousIPs.forEach(record => {
                this.suspiciousIPs.add(record.ip_address);
            });
            
            console.log(`✅ تم تحميل ${this.suspiciousIPs.size} IPs مشبوهة`);
        } catch (error) {
            console.error('❌ خطأ في تحميل بيانات التهديدات:', error);
        }
    }

    detectThreats(ip, userAgent, requestData = {}) {
        let threatScore = 0;
        const threats = [];

        // كشف IPs مشبوهة
        if (this.suspiciousIPs.has(ip)) {
            threatScore += 30;
            threats.push('IP مشبوه');
        }

        // كشف user agents مشبوهة
        if (this.isSuspiciousUserAgent(userAgent)) {
            threatScore += 20;
            threats.push('User Agent مشبوه');
        }

        // كشف هجمات Brute Force
        const attempts = this.failedAttempts.get(ip) || 0;
        if (attempts > 5) {
            threatScore += 25;
            threats.push('هجوم Brute Force محتمل');
        }

        // كشف أنماط SQL Injection
        if (this.detectSQLInjection(requestData)) {
            threatScore += 40;
            threats.push('محاولة SQL Injection');
        }

        // كشف أنماط XSS
        if (this.detectXSS(requestData)) {
            threatScore += 35;
            threats.push('محاولة XSS');
        }

        this.threatLevel = Math.min(threatScore, 100);
        
        if (threatScore > 0) {
            this.logSecurityEvent('THREAT_DETECTED', {
                ip,
                userAgent,
                threatScore,
                threats,
                requestData
            });
        }

        return threatScore;
    }

    isSuspiciousUserAgent(userAgent) {
        if (!userAgent) return true;
        
        const suspiciousPatterns = [
            /nikto/i,
            /sqlmap/i,
            /metasploit/i,
            /nmap/i,
            /wget/i,
            /curl/i,
            /python-requests/i,
            /go-http-client/i
        ];

        return suspiciousPatterns.some(pattern => pattern.test(userAgent));
    }

    detectSQLInjection(data) {
        const sqlPatterns = [
            /(\%27)|(\')|(\-\-)|(\%23)|(#)/i,
            /((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))/i,
            /w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))/i,
            /((\%27)|(\'))union/i,
            /exec(\s|\+)+(s|x)p\w+/i,
            /insert\s+into/i,
            /drop\s+table/i,
            /delete\s+from/i
        ];

        const dataString = JSON.stringify(data).toLowerCase();
        return sqlPatterns.some(pattern => pattern.test(dataString));
    }

    detectXSS(data) {
        const xssPatterns = [
            /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
            /javascript:/i,
            /on\w+\s*=/i,
            /<iframe/i,
            /<object/i,
            /<embed/i,
            /<applet/i,
            /meta\s+http-equiv=/i
        ];

        const dataString = JSON.stringify(data);
        return xssPatterns.some(pattern => pattern.test(dataString));
    }

    validateInput(data) {
        const errors = [];
        const validatedData = {};

        for (const [key, value] of Object.entries(data)) {
            if (value === undefined || value === null) {
                errors.push(`الحقل ${key} مطلوب`);
                continue;
            }

            // التحقق من نوع البيانات وطولها
            switch (key) {
                case 'username':
                case 'busNumber':
                    if (typeof value !== 'string') {
                        errors.push(`الحقل ${key} يجب أن يكون نصاً`);
                    } else if (value.length < 3) {
                        errors.push(`الحقل ${key} يجب أن يكون 3 أحرف على الأقل`);
                    } else {
                        validatedData[key] = value.trim();
                    }
                    break;

                case 'password':
                    if (typeof value !== 'string') {
                        errors.push(`كلمة السر يجب أن تكون نصاً`);
                    } else if (value.length < 4) {
                        errors.push(`كلمة السر يجب أن تكون 4 أحرف على الأقل`);
                    } else {
                        validatedData[key] = value;
                    }
                    break;

                case 'email':
                    if (typeof value !== 'string' || !this.isValidEmail(value)) {
                        errors.push(`البريد الإلكتروني غير صالح`);
                    } else {
                        validatedData[key] = value.trim().toLowerCase();
                    }
                    break;

                case 'phone':
                    if (typeof value !== 'string' || !this.isValidPhone(value)) {
                        errors.push(`رقم الهاتف غير صالح`);
                    } else {
                        validatedData[key] = value.trim();
                    }
                    break;

                default:
                    // التحقق الأساسي لجميع الحقول
                    if (typeof value === 'string' && value.length > 1000) {
                        errors.push(`الحقل ${key} طويل جداً`);
                    } else {
                        validatedData[key] = value;
                    }
            }
        }

        return {
            valid: errors.length === 0,
            errors,
            data: validatedData
        };
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    isValidPhone(phone) {
        const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
        return phoneRegex.test(phone);
    }

    recordFailedAttempt(ip, username = '') {
        const currentAttempts = this.failedAttempts.get(ip) || 0;
        this.failedAttempts.set(ip, currentAttempts + 1);

        // إذا تجاوزت المحاولات حداً معيناً، إضافة IP إلى القائمة السوداء
        if (currentAttempts + 1 >= 10) {
            this.suspiciousIPs.add(ip);
            this.logSecurityEvent('IP_BLOCKED', {
                ip,
                username,
                attempts: currentAttempts + 1,
                reason: 'too_many_failed_attempts'
            });
        }

        this.logSecurityEvent('LOGIN_ATTEMPT_FAILED', {
            ip,
            username,
            attemptNumber: currentAttempts + 1
        });
    }

    resetFailedAttempts(ip) {
        this.failedAttempts.delete(ip);
    }

    async logSecurityEvent(eventType, eventData) {
        const timestamp = new Date().toISOString();
        const event = {
            type: eventType,
            data: eventData,
            timestamp,
            severity: this.determineSeverity(eventType)
        };

        this.securityEvents.push(event);

        // حفظ في قاعدة البيانات
        try {
            await this.db.run(
                `INSERT INTO security_logs (event_type, event_data, ip_address, user_agent, severity, timestamp) 
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [
                    eventType,
                    JSON.stringify(eventData),
                    eventData.ip,
                    eventData.userAgent,
                    event.severity,
                    timestamp
                ]
            );
        } catch (error) {
            console.error('❌ خطأ في حفظ الحدث الأمني:', error);
        }

        // إرسال إشعار للمشرفين إذا كان الحدث خطير
        if (event.severity === 'high') {
            this.notifyAdmins(event);
        }

        console.log(`🔒 [${timestamp}] ${eventType}:`, eventData);
    }

    determineSeverity(eventType) {
        const highSeverityEvents = [
            'SQL_INJECTION_ATTEMPT',
            'XSS_ATTEMPT',
            'BRUTE_FORCE_ATTACK',
            'IP_BLOCKED',
            'UNAUTHORIZED_ACCESS'
        ];

        const mediumSeverityEvents = [
            'THREAT_DETECTED',
            'SUSPICIOUS_ACTIVITY',
            'MULTIPLE_FAILED_ATTEMPTS'
        ];

        if (highSeverityEvents.includes(eventType)) {
            return 'high';
        } else if (mediumSeverityEvents.includes(eventType)) {
            return 'medium';
        } else {
            return 'low';
        }
    }

    notifyAdmins(event) {
        // هنا يمكن إضافة منطق إرسال الإشعارات
        // مثل إرسال بريد إلكتروني، أو إشعار push، أو رسالة إلى نظام المراقبة
        console.warn('🚨 إشعار أمني عالي:', event);
        
        // مثال: إرسال إلى جميع المشرفين المتصلين
        if (global.wss) {
            const message = {
                type: 'security_alert',
                event: event.type,
                message: `حدث أمني: ${event.type}`,
                severity: event.severity,
                timestamp: event.timestamp,
                data: event.data
            };

            global.wss.clients.forEach(client => {
                if (client.readyState === require('ws').OPEN && 
                    (client.userType === 'super_admin' || client.userType === 'company_admin')) {
                    client.send(JSON.stringify(message));
                }
            });
        }
    }

    generateSecureToken() {
        return crypto.randomBytes(32).toString('hex');
    }

    validateSecureToken(token) {
        if (typeof token !== 'string' || token.length !== 64) {
            return false;
        }
        return /^[a-f0-9]{64}$/.test(token);
    }

    encryptData(data, key) {
        const algorithm = 'aes-256-gcm';
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipher(algorithm, key);
        
        let encrypted = cipher.update(data, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        
        const authTag = cipher.getAuthTag();
        
        return {
            iv: iv.toString('hex'),
            data: encrypted,
            authTag: authTag.toString('hex')
        };
    }

    decryptData(encryptedData, key) {
        try {
            const algorithm = 'aes-256-gcm';
            const decipher = crypto.createDecipher(algorithm, key);
            
            decipher.setAuthTag(Buffer.from(encryptedData.authTag, 'hex'));
            
            let decrypted = decipher.update(encryptedData.data, 'hex', 'utf8');
            decrypted += decipher.final('utf8');
            
            return decrypted;
        } catch (error) {
            this.logSecurityEvent('DECRYPTION_FAILED', {
                error: error.message,
                data: encryptedData
            });
            return null;
        }
    }

    async getSecurityReport() {
        try {
            const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
            
            const [
                totalEvents,
                highSeverityEvents,
                blockedIPs,
                recentThreats
            ] = await Promise.all([
                this.db.get('SELECT COUNT(*) as count FROM security_logs WHERE timestamp > ?', [last24Hours]),
                this.db.get('SELECT COUNT(*) as count FROM security_logs WHERE severity = "high" AND timestamp > ?', [last24Hours]),
                this.db.get('SELECT COUNT(DISTINCT ip_address) as count FROM security_logs WHERE severity = "high" AND timestamp > ?', [last24Hours]),
                this.db.all('SELECT event_type, COUNT(*) as count FROM security_logs WHERE timestamp > ? GROUP BY event_type ORDER BY count DESC LIMIT 10', [last24Hours])
            ]);

            return {
                period: '24_hours',
                totalEvents: totalEvents.count,
                highSeverityEvents: highSeverityEvents.count,
                blockedIPs: blockedIPs.count,
                threatLevel: this.threatLevel,
                recentThreats: recentThreats,
                suspiciousIPs: Array.from(this.suspiciousIPs).slice(0, 10),
                failedAttempts: Array.from(this.failedAttempts.entries()).slice(0, 10)
            };
        } catch (error) {
            console.error('❌ خطأ في إنشاء التقرير الأمني:', error);
            return { error: error.message };
        }
    }

    async cleanupOldData() {
        try {
            const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
            
            await this.db.run(
                'DELETE FROM security_logs WHERE timestamp < ? AND severity = "low"',
                [thirtyDaysAgo]
            );

            // تنظيف بيانات المحاولات الفاشلة القديمة
            for (const [ip, attempts] of this.failedAttempts.entries()) {
                if (attempts < 3) {
                    this.failedAttempts.delete(ip);
                }
            }

            console.log('✅ تم تنظيف البيانات الأمنية القديمة');
        } catch (error) {
            console.error('❌ خطأ في تنظيف البيانات الأمنية:', error);
        }
    }
}

// إنشاء instance واحدة من مدير الأمان
const securityManager = new SecurityManager();

// تصدير الدوال للاستخدام
module.exports = {
    // التهيئة
    initSecurity: () => securityManager.init(),

    // كشف التهديدات
    detectThreats: (ip, userAgent, requestData) => 
        securityManager.detectThreats(ip, userAgent, requestData),

    // تحقق من صحة المدخلات
    validateInput: (data) => securityManager.validateInput(data),

    // تسجيل الأحداث الأمنية
    logSecurityEvent: (eventType, eventData) => 
        securityManager.logSecurityEvent(eventType, eventData),

    // إدارة المحاولات الفاشلة
    recordFailedAttempt: (ip, username) => 
        securityManager.recordFailedAttempt(ip, username),
    
    resetFailedAttempts: (ip) => securityManager.resetFailedAttempts(ip),

    // التشفير
    generateSecureToken: () => securityManager.generateSecureToken(),
    validateSecureToken: (token) => securityManager.validateSecureToken(token),
    encryptData: (data, key) => securityManager.encryptData(data, key),
    decryptData: (encryptedData, key) => securityManager.decryptData(encryptedData, key),

    // التقارير
    getSecurityReport: () => securityManager.getSecurityReport(),

    // التنظيف
    cleanupSecurityData: () => securityManager.cleanupOldData()
};