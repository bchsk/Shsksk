const os = require('os');
const { initializeDatabase } = require('../config/database');

class PerformanceMonitor {
    constructor() {
        this.metrics = {
            cpu: { usage: 0, history: [] },
            memory: { usage: 0, history: [] },
            network: { in: 0, out: 0, history: [] },
            connections: { active: 0, total: 0, history: [] },
            messages: { processed: 0, rate: 0, history: [] },
            responseTime: { average: 0, history: [] },
            p2p: { connections: 0, quality: 100, history: [] }
        };
        
        this.thresholds = {
            cpu: 80,
            memory: 85,
            connections: 1000,
            responseTime: 1000, // ms
            p2pQuality: 70
        };
        
        this.alerts = [];
        this.db = null;
        this.startTime = Date.now();
        
        this.init();
    }

    async init() {
        this.db = await initializeDatabase();
        this.startMonitoring();
        console.log('✅ نظام مراقبة الأداء يعمل');
    }

    startMonitoring() {
        // مراقبة استخدام الموارد كل 5 ثواني
        setInterval(() => this.monitorSystemResources(), 5000);
        
        // مراقبة قاعدة البيانات كل 30 ثانية
        setInterval(() => this.monitorDatabase(), 30000);
        
        // حفظ المقاييس كل دقيقة
        setInterval(() => this.saveMetrics(), 60000);
        
        // تنظيف البيانات القديمة كل ساعة
        setInterval(() => this.cleanupOldMetrics(), 3600000);
    }

    monitorSystemResources() {
        // استخدام CPU
        const cpuUsage = os.loadavg()[0] / os.cpus().length * 100;
        this.updateMetric('cpu', cpuUsage);
        
        // استخدام الذاكرة
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        const memoryUsage = ((totalMem - freeMem) / totalMem) * 100;
        this.updateMetric('memory', memoryUsage);
        
        // مراقبة العتبات
        this.checkThresholds();
    }

    async monitorDatabase() {
        try {
            // مراقبة أداء قاعدة البيانات
            const startTime = Date.now();
            
            // اختبار استعلام بسيط
            await this.db.get('SELECT 1');
            
            const responseTime = Date.now() - startTime;
            this.updateMetric('responseTime', responseTime);
            
            // الحصول على إحصائيات الاتصالات
            const connections = await this.db.get(
                'SELECT COUNT(*) as count FROM sqlite_master'
            );
            
            this.updateMetric('connections', connections.count);
            
        } catch (error) {
            console.error('❌ خطأ في مراقبة قاعدة البيانات:', error);
            this.recordAlert('DATABASE_ERROR', `خطأ في قاعدة البيانات: ${error.message}`);
        }
    }

    updateMetric(metric, value) {
        if (!this.metrics[metric]) return;
        
        this.metrics[metric].usage = value;
        this.metrics[metric].history.push({
            value,
            timestamp: Date.now()
        });
        
        // الحفاظ على آخر 100 قراءة فقط
        if (this.metrics[metric].history.length > 100) {
            this.metrics[metric].history = this.metrics[metric].history.slice(-100);
        }
        
        // حساب المتوسط المتحرك
        if (this.metrics[metric].history.length > 0) {
            const avg = this.metrics[metric].history.reduce((sum, point) => sum + point.value, 0) 
                       / this.metrics[metric].history.length;
            this.metrics[metric].average = avg;
        }
    }

    checkThresholds() {
        const checks = [
            { metric: 'cpu', value: this.metrics.cpu.usage, threshold: this.thresholds.cpu },
            { metric: 'memory', value: this.metrics.memory.usage, threshold: this.thresholds.memory },
            { metric: 'responseTime', value: this.metrics.responseTime.usage, threshold: this.thresholds.responseTime },
            { metric: 'p2p', value: this.metrics.p2p.quality, threshold: this.thresholds.p2pQuality }
        ];
        
        checks.forEach(check => {
            if (check.value > check.threshold) {
                this.recordAlert(
                    'PERFORMANCE_THRESHOLD_EXCEEDED',
                    `${check.metric} تجاوز العتبة: ${check.value.toFixed(2)}% (الحد: ${check.threshold}%)`,
                    'warning'
                );
            }
        });
    }

    recordAlert(type, message, severity = 'warning') {
        const alert = {
            type,
            message,
            severity,
            timestamp: Date.now(),
            metrics: { ...this.metrics }
        };
        
        this.alerts.push(alert);
        
        // إرسال إشعار للمشرفين
        this.notifyAdmins(alert);
        
        // حفظ التنبيه
        this.saveAlert(alert);
        
        console.log(`🚨 تنبيه أداء [${severity}]: ${message}`);
    }

    notifyAdmins(alert) {
        if (global.wss) {
            const message = {
                type: 'performance_alert',
                alert: alert.type,
                message: alert.message,
                severity: alert.severity,
                timestamp: alert.timestamp,
                metrics: alert.metrics
            };
            
            global.wss.clients.forEach(client => {
                if (client.readyState === require('ws').OPEN && 
                    client.userType === 'super_admin') {
                    client.send(JSON.stringify(message));
                }
            });
        }
    }

    async saveMetrics() {
        try {
            const timestamp = new Date().toISOString();
            
            // حفظ مقاييس الأداء
            const metricsToSave = [
                { name: 'cpu_usage', value: this.metrics.cpu.usage },
                { name: 'memory_usage', value: this.metrics.memory.usage },
                { name: 'active_connections', value: this.metrics.connections.usage },
                { name: 'response_time', value: this.metrics.responseTime.usage },
                { name: 'p2p_quality', value: this.metrics.p2p.quality },
                { name: 'messages_processed', value: this.metrics.messages.processed }
            ];
            
            for (const metric of metricsToSave) {
                await this.db.run(
                    'INSERT INTO performance_metrics (metric_name, metric_value, timestamp) VALUES (?, ?, ?)',
                    [metric.name, metric.value, timestamp]
                );
            }
            
        } catch (error) {
            console.error('❌ خطأ في حفظ مقاييس الأداء:', error);
        }
    }

    async saveAlert(alert) {
        try {
            await this.db.run(
                `INSERT INTO security_logs (event_type, event_data, severity, timestamp) 
                 VALUES (?, ?, ?, ?)`,
                [
                    alert.type,
                    JSON.stringify({
                        message: alert.message,
                        metrics: alert.metrics
                    }),
                    alert.severity,
                    new Date(alert.timestamp).toISOString()
                ]
            );
        } catch (error) {
            console.error('❌ خطأ في حفظ التنبيه:', error);
        }
    }

    async cleanupOldMetrics() {
        try {
            const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
            
            await this.db.run(
                'DELETE FROM performance_metrics WHERE timestamp < ?',
                [sevenDaysAgo]
            );
            
            // تنظيف التنبيهات القديمة
            this.alerts = this.alerts.filter(alert => 
                alert.timestamp > Date.now() - 24 * 60 * 60 * 1000
            );
            
        } catch (error) {
            console.error('❌ خطأ في تنظيف مقاييس الأداء:', error);
        }
    }

    updateMessageMetrics(messagesProcessed) {
        const now = Date.now();
        const lastMinuteMessages = this.metrics.messages.history
            .filter(point => point.timestamp > now - 60000)
            .reduce((sum, point) => sum + point.value, 0);
        
        this.metrics.messages.processed = messagesProcessed;
        this.metrics.messages.rate = lastMinuteMessages;
        
        this.metrics.messages.history.push({
            value: messagesProcessed,
            timestamp: now
        });
        
        if (this.metrics.messages.history.length > 100) {
            this.metrics.messages.history = this.metrics.messages.history.slice(-100);
        }
    }

    updateP2PMetrics(connections, quality) {
        this.metrics.p2p.connections = connections;
        this.metrics.p2p.quality = quality;
        
        this.metrics.p2p.history.push({
            connections,
            quality,
            timestamp: Date.now()
        });
        
        if (this.metrics.p2p.history.length > 50) {
            this.metrics.p2p.history = this.metrics.p2p.history.slice(-50);
        }
    }

    getPerformanceMetrics() {
        const uptime = Date.now() - this.startTime;
        
        return {
            cpu: {
                usage: this.metrics.cpu.usage,
                average: this.metrics.cpu.average,
                cores: os.cpus().length
            },
            memory: {
                usage: this.metrics.memory.usage,
                total: os.totalmem(),
                free: os.freemem(),
                average: this.metrics.memory.average
            },
            network: {
                in: this.metrics.network.in,
                out: this.metrics.network.out
            },
            connections: {
                active: this.metrics.connections.usage,
                total: this.metrics.connections.total
            },
            messages: {
                processed: this.metrics.messages.processed,
                rate: this.metrics.messages.rate
            },
            responseTime: {
                average: this.metrics.responseTime.average,
                current: this.metrics.responseTime.usage
            },
            p2p: {
                connections: this.metrics.p2p.connections,
                quality: this.metrics.p2p.quality
            },
            system: {
                uptime,
                loadAverage: os.loadavg(),
                platform: os.platform(),
                arch: os.arch()
            },
            alerts: this.alerts.slice(-10) // آخر 10 تنبيهات
        };
    }

    async getPerformanceReport(period = '1h') {
        try {
            let timeRange = '1 hour';
            switch (period) {
                case '24h': timeRange = '24 hours'; break;
                case '7d': timeRange = '7 days'; break;
                case '30d': timeRange = '30 days'; break;
            }
            
            const metrics = await this.db.all(`
                SELECT metric_name, AVG(metric_value) as average, MAX(metric_value) as peak,
                       MIN(metric_value) as low, COUNT(*) as samples
                FROM performance_metrics 
                WHERE timestamp > datetime('now', ?)
                GROUP BY metric_name
            `, [`-${timeRange}`]);
            
            const alerts = await this.db.all(`
                SELECT event_type, COUNT(*) as count, severity
                FROM security_logs 
                WHERE timestamp > datetime('now', ?) AND event_type LIKE 'PERFORMANCE_%'
                GROUP BY event_type, severity
            `, [`-${timeRange}`]);
            
            return {
                period,
                metrics: metrics.reduce((acc, metric) => {
                    acc[metric.metric_name] = {
                        average: metric.average,
                        peak: metric.peak,
                        low: metric.low,
                        samples: metric.samples
                    };
                    return acc;
                }, {}),
                alerts,
                summary: {
                    totalAlerts: alerts.reduce((sum, alert) => sum + alert.count, 0),
                    highSeverityAlerts: alerts.filter(a => a.severity === 'high').length,
                    systemUptime: Date.now() - this.startTime
                }
            };
            
        } catch (error) {
            console.error('❌ خطأ في إنشاء تقرير الأداء:', error);
            return { error: error.message };
        }
    }
}

// إنشاء instance واحدة من مراقب الأداء
const performanceMonitor = new PerformanceMonitor();

// تصدير الدوال للاستخدام
module.exports = {
    // التهيئة
    startPerformanceMonitoring: () => performanceMonitor.init(),
    
    // الحصول على المقاييس
    getPerformanceMetrics: () => performanceMonitor.getPerformanceMetrics(),
    
    // تحديث المقاييس
    updateMessageMetrics: (messagesProcessed) => 
        performanceMonitor.updateMessageMetrics(messagesProcessed),
    
    updateP2PMetrics: (connections, quality) => 
        performanceMonitor.updateP2PMetrics(connections, quality),
    
    // التقارير
    getPerformanceReport: (period) => performanceMonitor.getPerformanceReport(period),
    
    // التنبيهات
    recordPerformanceAlert: (type, message, severity) => 
        performanceMonitor.recordAlert(type, message, severity)
};