const { initializeDatabase } = require('../config/database');

class EmergencyManager {
    constructor() {
        this.stunStatus = {
            primary: { active: true, lastCheck: Date.now(), failures: 0 },
            backup: { active: true, currentIndex: 0, servers: [] }
        };
        
        this.emergencyMode = false;
        this.recoveryAttempts = 0;
        this.db = null;
        this.emergencyProcedures = new Map();
        
        this.init();
    }

    async init() {
        this.db = await initializeDatabase();
        this.loadEmergencyProcedures();
        this.startHealthChecks();
        console.log('✅ نظام إدارة الطوارئ يعمل');
    }

    loadEmergencyProcedures() {
        // إجراءات الطوارئ المحددة مسبقاً
        this.emergencyProcedures.set('STUN_FAILURE', {
            name: 'فشل خادم STUN',
            severity: 'high',
            steps: [
                'التحقق من حالة الخادم الأساسي',
                'التبديل إلى الخادم الاحتياطي',
                'إشعار جميع العملاء بالتغيير',
                'محاولة استعادة الخادم الأساسي'
            ],
            autoExecute: true
        });

        this.emergencyProcedures.set('DATABASE_CONNECTION_LOST', {
            name: 'فقدان اتصال قاعدة البيانات',
            severity: 'critical',
            steps: [
                'محاولة إعادة الاتصال التلقائي',
                'استخدام نسخة احتياطية مؤقتة',
                'تنبيه المشرفين',
                'تفعيل وضع الطوارئ'
            ],
            autoExecute: true
        });

        this.emergencyProcedures.set('HIGH_LOAD', {
            name: 'حمل مرتفع على النظام',
            severity: 'medium',
            steps: [
                'تفعيل موازنة الحمل',
                'تقليل الخدمات غير الأساسية',
                'زيادة موارد النظام',
                'مراقبة الأداء المستمر'
            ],
            autoExecute: true
        });

        this.emergencyProcedures.set('SECURITY_BREACH', {
            name: 'اختراق أمني',
            severity: 'critical',
            steps: [
                'عزل النظام المتأثر',
                'تفعيل جدار الحماية',
                'تغيير جميع كلمات السر',
                'تنبيه فريق الأمان',
                'بدء التحقيق الأمني'
            ],
            autoExecute: false
        });
    }

    startHealthChecks() {
        // فحص صحة STUN كل 30 ثانية
        setInterval(() => this.checkSTUNHealth(), 30000);
        
        // فحص صحة قاعدة البيانات كل دقيقة
        setInterval(() => this.checkDatabaseHealth(), 60000);
        
        // فحص الحمل النظامي كل 10 ثواني
        setInterval(() => this.checkSystemLoad(), 10000);
    }

    async checkSTUNHealth() {
        try {
            // محاكاة فحص خادم STUN
            const isPrimaryHealthy = await this.pingSTUNServer('primary');
            
            if (!isPrimaryHealthy) {
                this.stunStatus.primary.failures++;
                
                if (this.stunStatus.primary.failures >= 3) {
                    await this.handleSTUNFailure('primary');
                }
            } else {
                this.stunStatus.primary.failures = 0;
                this.stunStatus.primary.lastCheck = Date.now();
            }
            
            // فحص الخوادم الاحتياطية
            await this.checkBackupSTUNServers();
            
        } catch (error) {
            console.error('❌ خطأ في فحص صحة STUN:', error);
            this.recordEmergencyEvent('STUN_HEALTH_CHECK_FAILED', {
                error: error.message,
                timestamp: Date.now()
            });
        }
    }

    async pingSTUNServer(serverType) {
        // محاكاة ping لخادم STUN
        // في التطبيق الحقيقي، هذا سيتضمن اتصال حقيقي بخادم STUN
        return new Promise((resolve) => {
            setTimeout(() => {
                // محاكاة فشل عشوائي بنسبة 5% للاختبار
                const isHealthy = Math.random() > 0.05;
                resolve(isHealthy);
            }, 1000);
        });
    }

    async checkBackupSTUNServers() {
        const backupServers = [
            'stun:stun.l.google.com:19302',
            'stun:stun1.l.google.com:19302',
            'stun:stun2.l.google.com:19302',
            'stun:stun3.l.google.com:19302'
        ];

        for (let i = 0; i < backupServers.length; i++) {
            const isHealthy = await this.pingSTUNServer('backup');
            if (isHealthy) {
                this.stunStatus.backup.currentIndex = i;
                this.stunStatus.backup.active = true;
                break;
            }
        }
    }

    async handleSTUNFailure(serverType, reason = 'unknown') {
        console.log(`🔄 فشل خادم STUN ${serverType}: ${reason}`);
        
        this.recordEmergencyEvent('STUN_FAILURE', {
            serverType,
            reason,
            timestamp: Date.now(),
            failures: this.stunStatus.primary.failures
        });

        if (serverType === 'primary') {
            await this.switchToBackupSTUN(reason);
        }
    }

    async switchToBackupSTUN(reason) {
        if (!this.stunStatus.backup.active) {
            this.recordEmergencyEvent('NO_BACKUP_STUN', {
                reason: 'لا توجد خوادم STUN احتياطية نشطة',
                timestamp: Date.now()
            });
            return false;
        }

        console.log(`🔀 التبديل إلى خادم STUN احتياطي: ${reason}`);
        
        this.stunStatus.primary.active = false;
        this.emergencyMode = true;

        // إشعار جميع العملاء بالتبديل
        this.notifyClientsAboutSTUNSwitch(reason);

        // بدء محاولات الاستعادة
        this.startRecoveryProcedure();

        this.recordEmergencyEvent('STUN_SWITCHED', {
            reason,
            backupServer: this.stunStatus.backup.currentIndex,
            timestamp: Date.now()
        });

        return true;
    }

    notifyClientsAboutSTUNSwitch(reason) {
        if (global.wss) {
            const message = {
                type: 'stun_switch',
                reason: reason,
                newServers: this.getActiveSTUNServers(),
                timestamp: Date.now(),
                emergencyMode: this.emergencyMode
            };

            let notifiedCount = 0;
            global.wss.clients.forEach(client => {
                if (client.readyState === require('ws').OPEN) {
                    client.send(JSON.stringify(message));
                    notifiedCount++;
                }
            });

            console.log(`📢 تم إشعار ${notifiedCount} عميل بالتبديل`);
        }
    }

    getActiveSTUNServers() {
        const servers = [];
        
        if (this.stunStatus.primary.active) {
            servers.push({ urls: 'stun:localhost:3478', primary: true });
        }
        
        // إضافة الخوادم الاحتياطية
        const backupUrls = [
            'stun:stun.l.google.com:19302',
            'stun:stun1.l.google.com:19302',
            'stun:stun2.l.google.com:19302'
        ];
        
        backupUrls.forEach(url => {
            servers.push({ urls: url, primary: false });
        });
        
        return servers;
    }

    startRecoveryProcedure() {
        this.recoveryAttempts = 0;
        const recoveryInterval = setInterval(async () => {
            this.recoveryAttempts++;
            
            const isRecovered = await this.attemptRecovery();
            
            if (isRecovered || this.recoveryAttempts >= 10) {
                clearInterval(recoveryInterval);
                
                if (isRecovered) {
                    console.log('✅ تم استعادة خادم STUN الأساسي');
                    this.stunStatus.primary.active = true;
                    this.stunStatus.primary.failures = 0;
                    this.emergencyMode = false;
                    
                    this.notifyClientsAboutRecovery();
                } else {
                    console.error('❌ فشل في استعادة خادم STUN بعد 10 محاولات');
                    this.recordEmergencyEvent('RECOVERY_FAILED', {
                        attempts: this.recoveryAttempts,
                        timestamp: Date.now()
                    });
                }
            }
        }, 30000); // محاولة كل 30 ثانية
    }

    async attemptRecovery() {
        try {
            const isHealthy = await this.pingSTUNServer('primary');
            return isHealthy;
        } catch (error) {
            console.error('❌ خطأ في محاولة الاستعادة:', error);
            return false;
        }
    }

    notifyClientsAboutRecovery() {
        if (global.wss) {
            const message = {
                type: 'stun_recovered',
                message: 'تم استعادة خادم STUN الأساسي',
                timestamp: Date.now(),
                emergencyMode: false
            };

            global.wss.clients.forEach(client => {
                if (client.readyState === require('ws').OPEN) {
                    client.send(JSON.stringify(message));
                }
            });
        }
    }

    async checkDatabaseHealth() {
        try {
            const startTime = Date.now();
            await this.db.get('SELECT 1');
            const responseTime = Date.now() - startTime;
            
            if (responseTime > 1000) { // إذا تجاوز الاستعلام ثانية واحدة
                this.recordEmergencyEvent('DATABASE_SLOW_RESPONSE', {
                    responseTime,
                    threshold: 1000,
                    timestamp: Date.now()
                });
            }
            
        } catch (error) {
            console.error('❌ فشل في فحص صحة قاعدة البيانات:', error);
            await this.handleDatabaseFailure(error);
        }
    }

    async handleDatabaseFailure(error) {
        this.recordEmergencyEvent('DATABASE_FAILURE', {
            error: error.message,
            timestamp: Date.now()
        });

        // محاولة إعادة الاتصال
        try {
            await this.db.close();
            this.db = await initializeDatabase();
            console.log('✅ تم إعادة الاتصال بقاعدة البيانات');
        } catch (reconnectError) {
            console.error('❌ فشل في إعادة الاتصال بقاعدة البيانات:', reconnectError);
            this.activateEmergencyMode('DATABASE_UNREACHABLE');
        }
    }

    checkSystemLoad() {
        const load = require('os').loadavg()[0];
        const cpuCount = require('os').cpus().length;
        const loadPercentage = (load / cpuCount) * 100;
        
        if (loadPercentage > 80) {
            this.recordEmergencyEvent('HIGH_SYSTEM_LOAD', {
                load: loadPercentage,
                threshold: 80,
                timestamp: Date.now()
            });
            
            this.triggerLoadBalancing();
        }
    }

    triggerLoadBalancing() {
        // تفعيل إجراءات موازنة الحمل
        console.log('⚖️ تفعيل موازنة الحمل due to high system load');
        
        // يمكن إضافة منطق لموازنة الحمل هنا
        // مثل تقليل تردد التحديثات، أو إيقاف الخدمات غير الأساسية
    }

    activateEmergencyMode(reason) {
        this.emergencyMode = true;
        console.log(`🚨 تفعيل وضع الطوارئ: ${reason}`);
        
        this.recordEmergencyEvent('EMERGENCY_MODE_ACTIVATED', {
            reason,
            timestamp: Date.now()
        });

        // تنبيه جميع المشرفين
        this.notifyAdminsAboutEmergency(reason);
    }

    notifyAdminsAboutEmergency(reason) {
        if (global.wss) {
            const message = {
                type: 'emergency_alert',
                reason: reason,
                timestamp: Date.now(),
                emergencyMode: true
            };

            global.wss.clients.forEach(client => {
                if (client.readyState === require('ws').OPEN && 
                    (client.userType === 'super_admin' || client.userType === 'company_admin')) {
                    client.send(JSON.stringify(message));
                }
            });
        }
    }

    async recordEmergencyEvent(eventType, eventData) {
        try {
            await this.db.run(
                `INSERT INTO security_logs (event_type, event_data, severity, timestamp) 
                 VALUES (?, ?, ?, ?)`,
                [
                    eventType,
                    JSON.stringify(eventData),
                    this.getEventSeverity(eventType),
                    new Date().toISOString()
                ]
            );
        } catch (error) {
            console.error('❌ خطأ في تسجيل حدث الطوارئ:', error);
        }
    }

    getEventSeverity(eventType) {
        const criticalEvents = [
            'DATABASE_FAILURE',
            'SECURITY_BREACH',
            'EMERGENCY_MODE_ACTIVATED'
        ];
        
        const highSeverityEvents = [
            'STUN_FAILURE',
            'NO_BACKUP_STUN',
            'HIGH_SYSTEM_LOAD'
        ];
        
        if (criticalEvents.includes(eventType)) {
            return 'critical';
        } else if (highSeverityEvents.includes(eventType)) {
            return 'high';
        } else {
            return 'medium';
        }
    }

    getEmergencyStatus() {
        return {
            emergencyMode: this.emergencyMode,
            stunStatus: this.stunStatus,
            recoveryAttempts: this.recoveryAttempts,
            activeProcedures: Array.from(this.emergencyProcedures.values())
                .filter(proc => proc.autoExecute)
        };
    }

    async getEmergencyReport() {
        try {
            const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
            
            const emergencies = await this.db.all(`
                SELECT event_type, COUNT(*) as count, severity
                FROM security_logs 
                WHERE timestamp > ? AND event_type IN (
                    'STUN_FAILURE', 'DATABASE_FAILURE', 'HIGH_SYSTEM_LOAD',
                    'EMERGENCY_MODE_ACTIVATED', 'SECURITY_BREACH'
                )
                GROUP BY event_type, severity
                ORDER BY count DESC
            `, [last24Hours]);
            
            return {
                period: '24_hours',
                totalEmergencies: emergencies.reduce((sum, e) => sum + e.count, 0),
                byType: emergencies,
                currentStatus: this.getEmergencyStatus(),
                recommendations: this.generateRecommendations(emergencies)
            };
            
        } catch (error) {
            console.error('❌ خطأ في إنشاء تقرير الطوارئ:', error);
            return { error: error.message };
        }
    }

    generateRecommendations(emergencies) {
        const recommendations = [];
        
        emergencies.forEach(emergency => {
            switch (emergency.event_type) {
                case 'STUN_FAILURE':
                    recommendations.push({
                        type: 'STUN_FAILURE',
                        message: 'زيادة عدد خوادم STUN الاحتياطية',
                        priority: 'high'
                    });
                    break;
                    
                case 'DATABASE_FAILURE':
                    recommendations.push({
                        type: 'DATABASE_FAILURE',
                        message: 'تحسين مراقبة قاعدة البيانات وإضافة نسخ احتياطية',
                        priority: 'critical'
                    });
                    break;
                    
                case 'HIGH_SYSTEM_LOAD':
                    recommendations.push({
                        type: 'HIGH_SYSTEM_LOAD',
                        message: 'ترقية موارد الخادم أو إضافة موازن حمل',
                        priority: 'medium'
                    });
                    break;
            }
        });
        
        return recommendations;
    }
}

// إنشاء instance واحدة من مدير الطوارئ
const emergencyManager = new EmergencyManager();

// تصدير الدوال للاستخدام
module.exports = {
    // التهيئة
    initEmergencyManager: () => emergencyManager.init(),
    
    // إدارة STUN
    handleSTUNFailure: (reason) => emergencyManager.handleSTUNFailure('primary', reason),
    switchToBackupSTUN: (reason) => emergencyManager.switchToBackupSTUN(reason),
    getSTUNStatus: () => emergencyManager.stunStatus,
    
    // الطوارئ العامة
    activateEmergencyMode: (reason) => emergencyManager.activateEmergencyMode(reason),
    getEmergencyStatus: () => emergencyManager.getEmergencyStatus(),
    getEmergencyReport: () => emergencyManager.getEmergencyReport(),
    
    // التسجيل
    recordEmergencyEvent: (eventType, eventData) => 
        emergencyManager.recordEmergencyEvent(eventType, eventData)
};