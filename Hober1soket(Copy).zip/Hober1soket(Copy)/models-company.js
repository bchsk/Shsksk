const { initializeDatabase } = require('../config/database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

class Company {
    constructor() {
        this.db = null;
        this.init();
    }

    async init() {
        this.db = await initializeDatabase();
    }

    async create(companyData) {
        const {
            name,
            maxBuses = 10,
            adminUsername,
            adminPassword,
            backupInterval = 6,
            status = 'active'
        } = companyData;

        try {
            // التحقق من عدم وجود شركة بنفس الاسم
            const existingCompany = await this.db.get(
                'SELECT id FROM companies WHERE name = ?',
                [name]
            );

            if (existingCompany) {
                throw new Error('شركة بنفس الاسم موجودة مسبقاً');
            }

            // إنشاء الشركة
            const companyUUID = uuidv4();
            const result = await this.db.run(
                `INSERT INTO companies (name, max_buses, backup_interval, status, uuid) 
                 VALUES (?, ?, ?, ?, ?)`,
                [name, maxBuses, backupInterval, status, companyUUID]
            );

            const companyId = result.lastID;

            // إنشاء مدير الشركة
            const hashedPassword = await bcrypt.hash(adminPassword, 12);
            await this.db.run(
                `INSERT INTO company_admins (company_id, username, password) 
                 VALUES (?, ?, ?)`,
                [companyId, adminUsername, hashedPassword]
            );

            // تسجيل الحدث
            await this.logCompanyEvent(companyId, 'COMPANY_CREATED', {
                name,
                maxBuses,
                adminUsername
            });

            return {
                id: companyId,
                uuid: companyUUID,
                name,
                maxBuses,
                status,
                message: 'تم إنشاء الشركة بنجاح'
            };

        } catch (error) {
            console.error('❌ خطأ في إنشاء الشركة:', error);
            throw error;
        }
    }

    async getById(companyId) {
        try {
            const company = await this.db.get(`
                SELECT c.*, 
                       (SELECT COUNT(*) FROM buses WHERE company_id = c.id AND status != 'deleted') as bus_count,
                       (SELECT COUNT(*) FROM buses WHERE company_id = c.id AND status = 'active') as active_buses
                FROM companies c 
                WHERE c.id = ? AND c.status != 'deleted'
            `, [companyId]);

            if (!company) {
                throw new Error('الشركة غير موجودة');
            }

            return company;
        } catch (error) {
            console.error('❌ خطأ في جلب بيانات الشركة:', error);
            throw error;
        }
    }

    async getByUUID(companyUUID) {
        try {
            const company = await this.db.get(`
                SELECT c.*, 
                       (SELECT COUNT(*) FROM buses WHERE company_id = c.id AND status != 'deleted') as bus_count,
                       (SELECT COUNT(*) FROM buses WHERE company_id = c.id AND status = 'active') as active_buses
                FROM companies c 
                WHERE c.uuid = ? AND c.status != 'deleted'
            `, [companyUUID]);

            return company;
        } catch (error) {
            console.error('❌ خطأ في جلب بيانات الشركة:', error);
            throw error;
        }
    }

    async update(companyId, updateData) {
        const allowedFields = ['name', 'max_buses', 'backup_interval', 'status'];
        const updates = [];
        const values = [];

        for (const [field, value] of Object.entries(updateData)) {
            if (allowedFields.includes(field)) {
                updates.push(`${field} = ?`);
                values.push(value);
            }
        }

        if (updates.length === 0) {
            throw new Error('لا توجد حقول صالحة للتحديث');
        }

        values.push(companyId);

        try {
            await this.db.run(
                `UPDATE companies SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP 
                 WHERE id = ?`,
                values
            );

            await this.logCompanyEvent(companyId, 'COMPANY_UPDATED', updateData);

            return { message: 'تم تحديث بيانات الشركة بنجاح' };
        } catch (error) {
            console.error('❌ خطأ في تحديث الشركة:', error);
            throw error;
        }
    }

    async suspend(companyId, reason = '') {
        try {
            await this.db.run(
                'UPDATE companies SET status = "suspended", updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                [companyId]
            );

            // إيقاف جميع حافلات الشركة
            await this.db.run(
                'UPDATE buses SET status = "stopped" WHERE company_id = ?',
                [companyId]
            );

            await this.logCompanyEvent(companyId, 'COMPANY_SUSPENDED', { reason });

            return { message: 'تم تعليق الشركة بنجاح' };
        } catch (error) {
            console.error('❌ خطأ في تعليق الشركة:', error);
            throw error;
        }
    }

    async activate(companyId) {
        try {
            await this.db.run(
                'UPDATE companies SET status = "active", updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                [companyId]
            );

            await this.logCompanyEvent(companyId, 'COMPANY_ACTIVATED', {});

            return { message: 'تم تفعيل الشركة بنجاح' };
        } catch (error) {
            console.error('❌ خطأ في تفعيل الشركة:', error);
            throw error;
        }
    }

    async delete(companyId) {
        try {
            // التحقق من عدم وجود حافلات نشطة
            const activeBuses = await this.db.get(
                'SELECT COUNT(*) as count FROM buses WHERE company_id = ? AND status = "active"',
                [companyId]
            );

            if (activeBuses.count > 0) {
                throw new Error('لا يمكن حذف شركة تحتوي على حافلات نشطة');
            }

            // وضع علامة محذوفة بدلاً من الحذف الفعلي
            await this.db.run(
                'UPDATE companies SET status = "deleted", updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                [companyId]
            );

            await this.logCompanyEvent(companyId, 'COMPANY_DELETED', {});

            return { message: 'تم حذف الشركة بنجاح' };
        } catch (error) {
            console.error('❌ خطأ في حذف الشركة:', error);
            throw error;
        }
    }

    async getAll(filter = {}) {
        try {
            let query = `
                SELECT c.*, 
                       (SELECT COUNT(*) FROM buses WHERE company_id = c.id AND status != 'deleted') as bus_count,
                       (SELECT COUNT(*) FROM buses WHERE company_id = c.id AND status = 'active') as active_buses,
                       (SELECT username FROM company_admins WHERE company_id = c.id LIMIT 1) as admin_username
                FROM companies c 
                WHERE c.status != 'deleted'
            `;
            const params = [];

            if (filter.status) {
                query += ' AND c.status = ?';
                params.push(filter.status);
            }

            if (filter.search) {
                query += ' AND (c.name LIKE ? OR c.uuid LIKE ?)';
                const searchTerm = `%${filter.search}%`;
                params.push(searchTerm, searchTerm);
            }

            query += ' ORDER BY c.created_at DESC';

            const companies = await this.db.all(query, params);
            return companies;
        } catch (error) {
            console.error('❌ خطأ في جلب قائمة الشركات:', error);
            throw error;
        }
    }

    async getUsageStatistics(companyId) {
        try {
            const stats = await this.db.get(`
                SELECT 
                    c.name,
                    c.max_buses,
                    COUNT(b.id) as total_buses,
                    SUM(CASE WHEN b.status = 'active' THEN 1 ELSE 0 END) as active_buses,
                    SUM(CASE WHEN b.status = 'stopped' THEN 1 ELSE 0 END) as stopped_buses,
                    SUM(b.total_distance) as total_distance,
                    AVG(b.speed) as avg_speed,
                    SUM(b.passengers) as total_passengers,
                    COUNT(DISTINCT d.id) as total_drivers
                FROM companies c
                LEFT JOIN buses b ON c.id = b.company_id AND b.status != 'deleted'
                LEFT JOIN drivers d ON b.bus_id = d.bus_id
                WHERE c.id = ?
                GROUP BY c.id
            `, [companyId]);

            const usagePercent = stats.total_buses > 0 ? 
                Math.round((stats.total_buses / stats.max_buses) * 100) : 0;

            return {
                ...stats,
                usage_percent: usagePercent,
                available_buses: Math.max(0, stats.max_buses - stats.total_buses)
            };
        } catch (error) {
            console.error('❌ خطأ في جلب إحصائيات الاستخدام:', error);
            throw error;
        }
    }

    async getPerformanceReport(companyId, period = '7d') {
        try {
            let timeRange = '7 days';
            switch (period) {
                case '1d': timeRange = '1 day'; break;
                case '30d': timeRange = '30 days'; break;
            }

            const report = await this.db.get(`
                SELECT 
                    COUNT(DISTINCT b.bus_id) as active_buses,
                    SUM(b.total_distance) as total_distance,
                    AVG(b.speed) as avg_speed,
                    SUM(b.passengers) as total_passengers,
                    COUNT(DISTINCT bl.id) as location_updates,
                    MAX(b.last_update) as last_activity
                FROM buses b
                LEFT JOIN bus_locations bl ON b.bus_id = bl.bus_id
                WHERE b.company_id = ? 
                AND b.last_update > datetime('now', ?)
                AND b.status != 'deleted'
            `, [companyId, `-${timeRange}`]);

            return {
                period,
                ...report,
                efficiency: report.total_distance > 0 ? 
                    Math.round((report.total_passengers / report.total_distance) * 100) / 100 : 0
            };
        } catch (error) {
            console.error('❌ خطأ في إنشاء تقرير الأداء:', error);
            throw error;
        }
    }

    async logCompanyEvent(companyId, eventType, eventData) {
        try {
            await this.db.run(
                `INSERT INTO security_logs (event_type, event_data, timestamp) 
                 VALUES (?, ?, ?)`,
                [
                    eventType,
                    JSON.stringify({
                        companyId,
                        ...eventData
                    }),
                    new Date().toISOString()
                ]
            );
        } catch (error) {
            console.error('❌ خطأ في تسجيل حدث الشركة:', error);
        }
    }

    async validateCompanyLimit(companyId) {
        try {
            const company = await this.getById(companyId);
            const currentBuses = await this.db.get(
                'SELECT COUNT(*) as count FROM buses WHERE company_id = ? AND status != "deleted"',
                [companyId]
            );

            return {
                canAddMore: currentBuses.count < company.max_buses,
                current: currentBuses.count,
                max: company.max_buses,
                remaining: Math.max(0, company.max_buses - currentBuses.count)
            };
        } catch (error) {
            console.error('❌ خطأ في التحقق من حدود الشركة:', error);
            throw error;
        }
    }

    async generateSecureLink(companyId) {
        try {
            const company = await this.getById(companyId);
            const secureToken = uuidv4();
            
            // حفظ التوكن في قاعدة البيانات
            await this.db.run(
                'UPDATE companies SET encryption_key = ? WHERE id = ?',
                [secureToken, companyId]
            );

            const secureLink = `/driver-register.html?company=${company.uuid}&token=${secureToken}`;
            
            await this.logCompanyEvent(companyId, 'SECURE_LINK_GENERATED', {
                link: secureLink
            });

            return secureLink;
        } catch (error) {
            console.error('❌ خطأ في إنشاء الرابط الآمن:', error);
            throw error;
        }
    }

    async validateSecureLink(companyUUID, token) {
        try {
            const company = await this.getByUUID(companyUUID);
            
            if (!company || company.status !== 'active') {
                return { valid: false, reason: 'الشركة غير موجودة أو غير نشطة' };
            }

            if (company.encryption_key !== token) {
                return { valid: false, reason: 'الرابط غير صالح' };
            }

            return { 
                valid: true, 
                companyId: company.id,
                companyName: company.name
            };
        } catch (error) {
            console.error('❌ خطأ في التحقق من الرابط الآمن:', error);
            return { valid: false, reason: 'خطأ في النظام' };
        }
    }
}

// إنشاء instance واحدة من نموذج الشركة
const companyModel = new Company();

// تصدير الدوال للاستخدام
module.exports = {
    // العمليات الأساسية
    createCompany: (companyData) => companyModel.create(companyData),
    getCompany: (companyId) => companyModel.getById(companyId),
    getCompanyByUUID: (companyUUID) => companyModel.getByUUID(companyUUID),
    updateCompany: (companyId, updateData) => companyModel.update(companyId, updateData),
    suspendCompany: (companyId, reason) => companyModel.suspend(companyId, reason),
    activateCompany: (companyId) => companyModel.activate(companyId),
    deleteCompany: (companyId) => companyModel.delete(companyId),
    
    // الاستعلامات
    getAllCompanies: (filter) => companyModel.getAll(filter),
    getCompanyUsage: (companyId) => companyModel.getUsageStatistics(companyId),
    getCompanyPerformance: (companyId, period) => companyModel.getPerformanceReport(companyId, period),
    
    // التحقق من الصلاحيات
    validateCompanyLimit: (companyId) => companyModel.validateCompanyLimit(companyId),
    
    // الأمان
    generateSecureLink: (companyId) => companyModel.generateSecureLink(companyId),
    validateSecureLink: (companyUUID, token) => companyModel.validateSecureLink(companyUUID, token)
};