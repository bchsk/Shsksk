const { initializeDatabase } = require('./config/database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

async function initDatabase() {
    try {
        console.log('🚀 جاري تهيئة قاعدة البيانات...');
        
        const db = await initializeDatabase();
        
        // إضافة بيانات تجريبية
        await addSampleData(db);
        
        console.log('✅ تم تهيئة قاعدة البيانات بنجاح!');
        console.log('📊 يمكنك الآن تشغيل النظام');
        
        await db.close();
    } catch (error) {
        console.error('❌ فشل في تهيئة قاعدة البيانات:', error);
        process.exit(1);
    }
}

async function addSampleData(db) {
    // التحقق إذا كانت هناك بيانات بالفعل
    const companiesCount = await db.get('SELECT COUNT(*) as count FROM companies');
    
    if (companiesCount.count === 0) {
        console.log('🔧 إضافة بيانات تجريبية...');
        
        // إضافة شركة تجريبية
        await db.run(
            `INSERT INTO companies (name, max_buses, status, backup_interval) VALUES (?, ?, ?, ?)`,
            ['شركة النقل السريع', 5, 'active', 6]
        );
        
        const company = await db.get('SELECT id, uuid FROM companies WHERE name = ?', ['شركة النقل السريع']);
        
        // إضافة مدير للشركة
        const hashedPassword = await bcrypt.hash('company123', 12);
        
        await db.run(
            `INSERT INTO company_admins (company_id, username, password) VALUES (?, ?, ?)`,
            [company.id, 'company_admin', hashedPassword]
        );
        
        // إضافة حافلات تجريبية
        const sampleBuses = [
            { 
                bus_id: 'BUS_001', 
                driver_name: 'أحمد محمد', 
                route: 'المدينة - الجامعة',
                uuid: uuidv4()
            },
            { 
                bus_id: 'BUS_002', 
                driver_name: 'خالد عبدالله', 
                route: 'المركز - المستشفى',
                uuid: uuidv4()
            },
            { 
                bus_id: 'BUS_003', 
                driver_name: 'محمد علي', 
                route: 'الشرق - الغرب',
                uuid: uuidv4()
            }
        ];
        
        for (const bus of sampleBuses) {
            await db.run(
                `INSERT INTO buses (bus_id, company_id, driver_name, route, status, uuid) VALUES (?, ?, ?, ?, ?, ?)`,
                [bus.bus_id, company.id, bus.driver_name, bus.route, 'stopped', bus.uuid]
            );
            
            const busPassword = await bcrypt.hash('12345', 12);
            const driverUUID = uuidv4();
            await db.run(
                `INSERT INTO drivers (bus_number, password, bus_id, driver_name, route, uuid) VALUES (?, ?, ?, ?, ?, ?)`,
                [bus.bus_id.replace('BUS_', ''), busPassword, bus.bus_id, bus.driver_name, bus.route, driverUUID]
            );
        }

        // إضافة سجلات أداء نموذجية
        await db.run(
            `INSERT INTO performance_metrics (metric_name, metric_value) VALUES (?, ?)`,
            ['active_connections', 0]
        );
        
        await db.run(
            `INSERT INTO performance_metrics (metric_name, metric_value) VALUES (?, ?)`,
            ['message_throughput', 0]
        );

        // إضافة سجلات أمان نموذجية
        await db.run(
            `INSERT INTO security_logs (event_type, event_data, severity) VALUES (?, ?, ?)`,
            ['SYSTEM_START', 'تم بدء النظام بنجاح', 'info']
        );
        
        console.log('✅ تم إضافة البيانات التجريبية');
        console.log('🏢 الشركة: شركة النقل السريع');
        console.log('👤 مدير الشركة: company_admin / company123');
        console.log('🚍 الحافلات: BUS_001, BUS_002, BUS_003');
        console.log('🔐 كلمة سر السائقين: 12345 لجميع الحافلات');
        console.log('🔑 جميع السجلات تحتوي على UUID فريد');
    } else {
        console.log('ℹ️  قاعدة البيانات تحتوي بالفعل على بيانات');
    }
}

// تشغيل التهيئة إذا تم استدعاء الملف مباشرة
if (require.main === module) {
    initDatabase();
}

module.exports = { initDatabase };