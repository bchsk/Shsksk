const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const crypto = require('crypto');
const { initializeDatabase } = require('./database');

class BackupManager {
    constructor() {
        this.backupDir = path.join(__dirname, '..', 'backups');
        this.encryptionKey = process.env.BACKUP_ENCRYPTION_KEY || this.generateEncryptionKey();
        this.ensureBackupDir();
    }

    ensureBackupDir() {
        if (!fs.existsSync(this.backupDir)) {
            fs.mkdirSync(this.backupDir, { recursive: true });
        }
    }

    generateEncryptionKey() {
        return crypto.randomBytes(32).toString('hex');
    }

    encryptData(data) {
        const algorithm = 'aes-256-gcm';
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipher(algorithm, Buffer.from(this.encryptionKey, 'hex'));
        
        let encrypted = cipher.update(data, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        
        const authTag = cipher.getAuthTag();
        
        return {
            iv: iv.toString('hex'),
            data: encrypted,
            authTag: authTag.toString('hex')
        };
    }

    decryptData(encryptedData) {
        const algorithm = 'aes-256-gcm';
        const decipher = crypto.createDecipher(algorithm, Buffer.from(this.encryptionKey, 'hex'));
        
        decipher.setAuthTag(Buffer.from(encryptedData.authTag, 'hex'));
        
        let decrypted = decipher.update(encryptedData.data, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        
        return decrypted;
    }

    async createBackup(backupType = 'full') {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupFileName = `backup-${backupType}-${timestamp}.db`;
        const backupPath = path.join(this.backupDir, backupFileName);
        
        try {
            const db = await initializeDatabase();
            
            // إنشاء نسخة احتياطية من قاعدة البيانات
            await new Promise((resolve, reject) => {
                const backup = db.backup(backupPath);
                backup.step(-1, function(err) {
                    if (err) reject(err);
                    else resolve();
                });
            });

            // تشفير النسخة الاحتياطية
            const backupData = fs.readFileSync(backupPath);
            const encryptedData = this.encryptData(backupData.toString('binary'));
            
            const encryptedBackupPath = backupPath + '.encrypted';
            fs.writeFileSync(encryptedBackupPath, JSON.stringify(encryptedData));
            
            // حذف النسخة غير المشفرة
            fs.unlinkSync(backupPath);
            
            const fileStats = fs.statSync(encryptedBackupPath);
            
            // تسجيل عملية النسخ الاحتياطي
            await db.run(
                `INSERT INTO backup_logs (backup_type, file_path, file_size, encrypted, status) 
                 VALUES (?, ?, ?, ?, ?)`,
                [backupType, encryptedBackupPath, fileStats.size, true, 'success']
            );

            console.log(`✅ تم إنشاء نسخة احتياطية ${backupType} مشفرة: ${encryptedBackupPath}`);
            
            // تنظيف النسخ الاحتياطية القديمة
            await this.cleanupOldBackups();
            
            return {
                success: true,
                filePath: encryptedBackupPath,
                fileSize: fileStats.size,
                timestamp: new Date()
            };
        } catch (error) {
            console.error('❌ فشل في إنشاء النسخة الاحتياطية:', error);
            
            try {
                const db = await initializeDatabase();
                await db.run(
                    `INSERT INTO backup_logs (backup_type, file_path, status) 
                     VALUES (?, ?, ?)`,
                    [backupType, backupPath, 'failed']
                );
            } catch (logError) {
                console.error('❌ فشل في تسجيل خطأ النسخ الاحتياطي:', logError);
            }
            
            return {
                success: false,
                error: error.message
            };
        }
    }

    async restoreBackup(backupFilePath) {
        try {
            if (!fs.existsSync(backupFilePath)) {
                throw new Error('ملف النسخة الاحتياطية غير موجود');
            }

            const encryptedData = JSON.parse(fs.readFileSync(backupFilePath, 'utf8'));
            const decryptedData = this.decryptData(encryptedData);
            
            const tempRestorePath = path.join(this.backupDir, 'temp_restore.db');
            fs.writeFileSync(tempRestorePath, decryptedData, 'binary');
            
            // استبدال قاعدة البيانات الحالية
            const currentDbPath = path.join(__dirname, '..', 'bus_tracking.db');
            fs.copyFileSync(tempRestorePath, currentDbPath);
            
            // تنظيف الملف المؤقت
            fs.unlinkSync(tempRestorePath);
            
            console.log('✅ تم استعادة النسخة الاحتياطية بنجاح');
            return { success: true };
        } catch (error) {
            console.error('❌ فشل في استعادة النسخة الاحتياطية:', error);
            return { success: false, error: error.message };
        }
    }

    async cleanupOldBackups() {
        try {
            const files = fs.readdirSync(this.backupDir);
            const backupFiles = files.filter(file => file.endsWith('.encrypted'));
            
            // الاحتفاظ بالنسخ الاحتياطية لآخر 7 أيام فقط
            const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
            
            for (const file of backupFiles) {
                const filePath = path.join(this.backupDir, file);
                const stats = fs.statSync(filePath);
                
                if (stats.mtime < sevenDaysAgo) {
                    fs.unlinkSync(filePath);
                    console.log(`🗑️  تم حذف النسخة الاحتياطية القديمة: ${file}`);
                }
            }
        } catch (error) {
            console.error('❌ خطأ في تنظيف النسخ الاحتياطية القديمة:', error);
        }
    }

    async getBackupStatus() {
        try {
            const db = await initializeDatabase();
            const recentBackups = await db.all(`
                SELECT * FROM backup_logs 
                WHERE timestamp > datetime('now', '-7 days') 
                ORDER BY timestamp DESC
            `);
            
            const backupFiles = fs.readdirSync(this.backupDir)
                .filter(file => file.endsWith('.encrypted'))
                .map(file => {
                    const filePath = path.join(this.backupDir, file);
                    const stats = fs.statSync(filePath);
                    return {
                        name: file,
                        size: stats.size,
                        modified: stats.mtime,
                        path: filePath
                    };
                });
            
            return {
                recentBackups: recentBackups,
                backupFiles: backupFiles,
                totalSize: backupFiles.reduce((sum, file) => sum + file.size, 0),
                encryptionEnabled: true
            };
        } catch (error) {
            console.error('❌ خطأ في الحصول على حالة النسخ الاحتياطي:', error);
            return { error: error.message };
        }
    }
}

// النسخ الاحتياطي التلقائي كل 6 ساعات
const backupManager = new BackupManager();
setInterval(async () => {
    console.log('🔄 جاري النسخ الاحتياطي التلقائي...');
    await backupManager.createBackup('auto');
}, 6 * 60 * 60 * 1000);

// النسخ الاحتياطي الفوري عند الطلب
if (require.main === module) {
    const args = process.argv.slice(2);
    const command = args[0];
    
    switch (command) {
        case 'create':
            backupManager.createBackup(args[1] || 'manual').then(console.log);
            break;
        case 'restore':
            if (args[1]) {
                backupManager.restoreBackup(args[1]).then(console.log);
            } else {
                console.log('❌ يرجى تحديد مسار ملف النسخة الاحتياطية');
            }
            break;
        case 'status':
            backupManager.getBackupStatus().then(console.log);
            break;
        case 'cleanup':
            backupManager.cleanupOldBackups();
            break;
        default:
            console.log(`
استخدامات سكريبت النسخ الاحتياطي:
  npm run backup create [type]    إنشاء نسخة احتياطية
  npm run backup restore [path]   استعادة نسخة احتياطية
  npm run backup status           عرض حالة النسخ الاحتياطي
  npm run backup cleanup          تنظيف النسخ القديمة
            `);
    }
}

module.exports = BackupManager;