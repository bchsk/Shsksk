const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const dbPath = path.join(__dirname, '..', 'bus_tracking.db');

async function initializeDatabase() {
    const db = await open({
        filename: dbPath,
        driver: sqlite3.Database
    });

    // تحسينات SSD متقدمة للأداء
    await db.exec(`
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous = NORMAL;
        PRAGMA cache_size = -64000;
        PRAGMA temp_store = memory;
        PRAGMA mmap_size = 30000000000;
        PRAGMA busy_timeout = 5000;
        PRAGMA auto_vacuum = INCREMENTAL;
        PRAGMA optimize;
        PRAGMA foreign_keys = ON;
        PRAGMA secure_delete = ON;
    `);

    // إنشاء الجداول
    await createTables(db);
    
    console.log('✅ قاعدة البيانات مهيأة مع تحسينات SSD متقدمة');
    return db;
}

async function createTables(db) {
    // جدول الشركات مع UUID
    await db.exec(`
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT NOT NULL UNIQUE DEFAULT (lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || substr('89ab', abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6)))),
            name TEXT NOT NULL UNIQUE,
            max_buses INTEGER NOT NULL DEFAULT 10,
            status TEXT DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            backup_interval INTEGER DEFAULT 6,
            encryption_key TEXT,
            CONSTRAINT chk_status CHECK (status IN ('active', 'suspended', 'inactive'))
        )
    `);

    // جدول مدراء الشركات
    await db.exec(`
        CREATE TABLE IF NOT EXISTS company_admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            login_attempts INTEGER DEFAULT 0,
            last_login_attempt DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
            CONSTRAINT chk_username_length CHECK (length(username) >= 3)
        )
    `);

    // جدول الحافلات مع UUID
    await db.exec(`
        CREATE TABLE IF NOT EXISTS buses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT NOT NULL UNIQUE DEFAULT (lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || substr('89ab', abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6)))),
            bus_id TEXT NOT NULL UNIQUE,
            company_id INTEGER NOT NULL,
            driver_name TEXT NOT NULL,
            route TEXT NOT NULL,
            status TEXT DEFAULT 'stopped',
            last_location_lat REAL,
            last_location_lng REAL,
            speed REAL DEFAULT 0,
            passengers INTEGER DEFAULT 0,
            total_distance REAL DEFAULT 0,
            last_update DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
            CONSTRAINT chk_status CHECK (status IN ('active', 'stopped', 'maintenance', 'deleted')),
            CONSTRAINT chk_passengers CHECK (passengers >= 0 AND passengers <= 100)
        )
    `);

    // جدول السائقين مع تشفير متقدم
    await db.exec(`
        CREATE TABLE IF NOT EXISTS drivers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT NOT NULL UNIQUE DEFAULT (lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || substr('89ab', abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6)))),
            bus_number TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            bus_id TEXT NOT NULL,
            driver_name TEXT NOT NULL,
            route TEXT NOT NULL,
            secure_link TEXT,
            link_expires DATETIME,
            login_attempts INTEGER DEFAULT 0,
            last_login_attempt DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (bus_id) REFERENCES buses (bus_id) ON DELETE CASCADE,
            CONSTRAINT chk_bus_number CHECK (length(bus_number) = 5 AND bus_number GLOB '[0-9][0-9][0-9][0-9][0-9]')
        )
    `);

    // جدول مواقع الحافلات مع تحسينات الفهرس
    await db.exec(`
        CREATE TABLE IF NOT EXISTS bus_locations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bus_id TEXT NOT NULL,
            location_lat REAL NOT NULL,
            location_lng REAL NOT NULL,
            speed REAL DEFAULT 0,
            passengers INTEGER DEFAULT 0,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            accuracy REAL DEFAULT 0,
            FOREIGN KEY (bus_id) REFERENCES buses (bus_id) ON DELETE CASCADE,
            CONSTRAINT chk_lat CHECK (location_lat BETWEEN -90 AND 90),
            CONSTRAINT chk_lng CHECK (location_lng BETWEEN -180 AND 180)
        )
    `);

    // جدول الرسائل مع التشفير
    await db.exec(`
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT NOT NULL UNIQUE DEFAULT (lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || substr('89ab', abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6)))),
            bus_id TEXT NOT NULL,
            sender_id TEXT NOT NULL,
            message TEXT NOT NULL,
            message_type TEXT DEFAULT 'text',
            is_read BOOLEAN DEFAULT 0,
            encrypted BOOLEAN DEFAULT 0,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (bus_id) REFERENCES buses (bus_id) ON DELETE CASCADE
        )
    `);

    // جدول سجلات الأمان
    await db.exec(`
        CREATE TABLE IF NOT EXISTS security_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            event_data TEXT NOT NULL,
            ip_address TEXT,
            user_agent TEXT,
            severity TEXT DEFAULT 'info',
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // جدول أداء النظام
    await db.exec(`
        CREATE TABLE IF NOT EXISTS performance_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name TEXT NOT NULL,
            metric_value REAL NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // جدول النسخ الاحتياطي
    await db.exec(`
        CREATE TABLE IF NOT EXISTS backup_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            backup_type TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_size INTEGER,
            status TEXT DEFAULT 'success',
            encrypted BOOLEAN DEFAULT 1,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // إنشاء indexes لتحسين الأداء
    await db.exec(`
        CREATE INDEX IF NOT EXISTS idx_buses_company ON buses(company_id);
        CREATE INDEX IF NOT EXISTS idx_buses_status ON buses(status);
        CREATE INDEX IF NOT EXISTS idx_buses_last_update ON buses(last_update);
        CREATE INDEX IF NOT EXISTS idx_buses_uuid ON buses(uuid);
        CREATE INDEX IF NOT EXISTS idx_locations_bus_timestamp ON bus_locations(bus_id, timestamp);
        CREATE INDEX IF NOT EXISTS idx_locations_timestamp ON bus_locations(timestamp);
        CREATE INDEX IF NOT EXISTS idx_messages_bus_timestamp ON messages(bus_id, timestamp);
        CREATE INDEX IF NOT EXISTS idx_messages_uuid ON messages(uuid);
        CREATE INDEX IF NOT EXISTS idx_drivers_bus_number ON drivers(bus_number);
        CREATE INDEX IF NOT EXISTS idx_drivers_uuid ON drivers(uuid);
        CREATE INDEX IF NOT EXISTS idx_company_admins_username ON company_admins(username);
        CREATE INDEX IF NOT EXISTS idx_companies_uuid ON companies(uuid);
        CREATE INDEX IF NOT EXISTS idx_companies_status ON companies(status);
        CREATE INDEX IF NOT EXISTS idx_security_logs_timestamp ON security_logs(timestamp);
        CREATE INDEX IF NOT EXISTS idx_security_logs_type ON security_logs(event_type);
        CREATE INDEX IF NOT EXISTS idx_performance_timestamp ON performance_metrics(timestamp);
    `);

    // إنشاء triggers للتحديث التلقائي
    await db.exec(`
        CREATE TRIGGER IF NOT EXISTS update_companies_timestamp 
        AFTER UPDATE ON companies
        FOR EACH ROW
        BEGIN
            UPDATE companies SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;

        CREATE TRIGGER IF NOT EXISTS update_buses_timestamp 
        AFTER UPDATE ON buses
        FOR EACH ROW
        BEGIN
            UPDATE buses SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;

        CREATE TRIGGER IF NOT EXISTS update_drivers_timestamp 
        AFTER UPDATE ON drivers
        FOR EACH ROW
        BEGIN
            UPDATE drivers SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;
    `);

    console.log('✅ جميع الجداول وال indexes و triggers تم إنشاؤها');
}

// دالة لتنظيف البيانات القديمة
async function cleanupOldData(db) {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    
    try {
        // حذف مواقع الحافلات القديمة
        await db.run('DELETE FROM bus_locations WHERE timestamp < ?', [thirtyDaysAgo]);
        
        // حذف سجلات الأداء القديمة
        await db.run('DELETE FROM performance_metrics WHERE timestamp < ?', [thirtyDaysAgo]);
        
        // حذف سجلات الأمان القديمة (احتفظ بـ 90 يوم)
        const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString();
        await db.run('DELETE FROM security_logs WHERE timestamp < ?', [ninetyDaysAgo]);
        
        console.log('✅ تم تنظيف البيانات القديمة بنجاح');
    } catch (error) {
        console.error('❌ خطأ في تنظيف البيانات القديمة:', error);
    }
}

// تشغيل التنظيف الدوري
setInterval(async () => {
    const db = await initializeDatabase();
    await cleanupOldData(db);
}, 24 * 60 * 60 * 1000); // كل 24 ساعة

module.exports = { initializeDatabase, cleanupOldData };